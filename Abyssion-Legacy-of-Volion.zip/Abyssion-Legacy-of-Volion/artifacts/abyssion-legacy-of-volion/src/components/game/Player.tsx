'use client';

import { useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { RigidBody, RapierRigidBody, CapsuleCollider, useRapier } from '@react-three/rapier';
import { useKeyboardControls } from '@react-three/drei';
import * as THREE from 'three';
import { useGameStore, enemyTargets } from '@/lib/store';
import { MOVEMENT_CONFIG as C } from '@/lib/movementConfig';
import { COMBAT_CONFIG as CC } from '@/lib/combatConfig';
import { combatAudio } from '@/lib/combatAudio';

const SPEED = C.walkSpeed;
const SPRINT_MULT = C.sprintMultiplier;
const JUMP_FORCE = C.jumpForce;
const DOUBLE_JUMP_FORCE = C.doubleJumpForce;
const ROTATION_SPEED = C.rotationSpeed;

export const playerRigidBodyRef = { current: null as RapierRigidBody | null };

export default function Player() {
  const rigidBodyRef = useRef<RapierRigidBody>(null);
  const playerMeshRef = useRef<THREE.Group>(null);
  const swordGroupRef = useRef<THREE.Group>(null);
  const swordPivotRef = useRef<THREE.Group>(null);
  const colliderRef = useRef<any>(null);
  
  const [, getKeys] = useKeyboardControls();
  const { camera } = useThree() as { camera: THREE.PerspectiveCamera };
  const { rapier, world } = useRapier();
  const setPlayerPosition = useGameStore(state => state.setPlayerPosition);
  // Capture the loaded/new-game position once when the physics body mounts.
  // The store follows physics thereafter, so passing the live position prop
  // would continually try to reset the body while it moves.
  const initialPlayerPosition = useRef<[number, number, number]>([
    ...useGameStore.getState().player.position,
  ]).current;

  // Jump state refs
  const isGroundedRef = useRef(true);
  const hasJumpedInAirRef = useRef(false);
  const prevJumpInputRef = useRef(false);

  // Dodge state refs
  const prevDodgeInputRef = useRef(false);
  const isDodgingRef = useRef(false);
  const dodgeTimerRef = useRef(0);
  const dodgeCooldownRef = useRef(0);
  const dodgeDirRef = useRef(new THREE.Vector3());

  // Attack state refs
  const prevAttackInputRef = useRef(false);
  const attackTimerRef = useRef(0);
  const attackComboStageRef = useRef(0);
  const hitEnemiesThisSwingRef = useRef<Set<string>>(new Set());

  // Camera state refs
  const currentCameraPos = useRef(new THREE.Vector3(0, 5, 10)).current;
  const currentLookAt = useRef(new THREE.Vector3(0, 0, 0)).current;
  const localShakeRef = useRef(0);
  const lastShakeReqIdRef = useRef(0);
  const hitStopTimerRef = useRef(0);
  const lastHitStopReqIdRef = useRef(0);
  const smoothedDistRef = useRef(6);

  // Movement polish refs
  const wasGroundedRef = useRef(true);       // for landing detection
  const landingDipRef = useRef(0);            // current camera dip offset (visual only)
  const squashScaleRef = useRef(1);           // body Y-scale for landing squash
  const headBobPhaseRef = useRef(0);          // accumulating phase for head bob
  const prevFootstepDistRef = useRef(0);     // distance accumulator for footstep cadence
  const currentFovRef = useRef<number>(C.baseFov);    // smoothed FOV for sprint transition

  // Respawn state ref
  const prevDeathOverlayRef = useRef(false);

  // Combat polish refs
  const weaponRecoilRef = useRef(0);           // current recoil offset
  const attackCamPushRef = useRef(0);          // current camera push offset
  const attackInputBufferRef = useRef(0);      // buffered attack press timer (seconds)
  const trailMeshRef = useRef<THREE.Mesh>(null);
  const trailAlphaRef = useRef(0);             // trail visibility alpha (0=hidden)

  // Reusable per-frame vectors (avoid GC pressure from repeated allocations)
  const _v1 = useRef(new THREE.Vector3()).current;
  const _v2 = useRef(new THREE.Vector3()).current;
  const _v3 = useRef(new THREE.Vector3()).current;
  const _v4 = useRef(new THREE.Vector3()).current;
  const _v5 = useRef(new THREE.Vector3()).current;
  const _groundRayDir = useRef(new THREE.Vector3(0, -1, 0)).current;
  const _groundRayOrigin = useRef(new THREE.Vector3()).current;
  // Reusable Ray objects — ground checks fire up to 5x/frame, camera 1x/frame.
  // Pre-allocating eliminates 6+ temporary Ray objects per frame.
  const _groundRay = useRef(new rapier.Ray(_groundRayOrigin, _groundRayDir)).current;
  const _camRay = useRef(new rapier.Ray(new THREE.Vector3(), new THREE.Vector3())).current;
  // Reusable position tuple for store updates (avoids a new array every frame)
  const _posTuple = useRef<[number, number, number]>([0, 0, 0]).current;

  useFrame((state, delta) => {
    if (!rigidBodyRef.current || !playerMeshRef.current) return;
    playerRigidBodyRef.current = rigidBodyRef.current;

    // Block all gameplay input while any modal, editor, or dialogue is open.
    // Regeneration still ticks (harmless) but movement/combat/camera are frozen.
    const uiState = useGameStore.getState().ui;
    const hudEditMode = useGameStore.getState().hudEditMode;
    const activeDialogue = useGameStore.getState().activeDialogue;
    if (uiState.showSettings || uiState.showInventory || uiState.showQuestLog || hudEditMode || activeDialogue) {
      // Zero out any residual velocity so the player doesn't drift
      rigidBodyRef.current.setLinvel({ x: 0, y: rigidBodyRef.current.linvel().y, z: 0 }, true);
      return;
    }

    // Tick Passive Regeneration (Health/Stamina) and Combat Recovery
    useGameStore.getState().tickRegenerationAndCombat(delta);

    // Sync rigid body position only on explicit respawn
    const deathOverlay = useGameStore.getState().ui.deathOverlay;
    if (prevDeathOverlayRef.current && !deathOverlay) {
      const cp = useGameStore.getState().player.checkpointPos;
      rigidBodyRef.current.setTranslation({ x: cp[0], y: cp[1], z: cp[2] }, true);
      rigidBodyRef.current.setLinvel({ x: 0, y: 0, z: 0 }, true);
    }
    prevDeathOverlayRef.current = deathOverlay;

    // Check camera shake and hit stop requests
    const { cameraShakeRequest, hitStopMsRequest } = useGameStore.getState();
    if (cameraShakeRequest && cameraShakeRequest.id !== lastShakeReqIdRef.current) {
      lastShakeReqIdRef.current = cameraShakeRequest.id;
      localShakeRef.current = Math.max(localShakeRef.current, cameraShakeRequest.intensity);
    }
    if (hitStopMsRequest && hitStopMsRequest.id !== lastHitStopReqIdRef.current) {
      lastHitStopReqIdRef.current = hitStopMsRequest.id;
      hitStopTimerRef.current = hitStopMsRequest.durationMs / 1000;
    }

    let effectiveDelta = delta;
    if (hitStopTimerRef.current > 0) {
      hitStopTimerRef.current -= delta;
      effectiveDelta = 0; // Freeze attack animation frame progress during hit stop
    }

    const { forward, backward, left, right, jump: keyJump, sprint: keySprint, attack: keyAttack, dodge: keyDodge } = getKeys();
    const { joystick, jump: storeJump, attack: storeAttack, dodge: storeDodge, sprint: storeSprint, cameraAngle, cameraPitch } = useGameStore.getState().inputs;
    const cameraMode = useGameStore.getState().settings.cameraMode;
    
    const jumpInput = keyJump || storeJump;
    const dodgeInput = keyDodge || storeDodge;
    const attackInput = keyAttack || storeAttack;
    const sprintInput = keySprint || storeSprint;

    const velocity = rigidBodyRef.current.linvel();
    const translation = rigidBodyRef.current.translation();
    
    // -------------------------------------------------------------
    // 1. GROUND CHECK & JUMP LOGIC
    // -------------------------------------------------------------
    // Dynamically query player collider dimensions & world position
    let halfHeight = 0.5;
    let radius = 0.5;
    let colliderOffsetY = 1.0;

    const playerCollider = colliderRef.current ? ((colliderRef.current as any).raw || colliderRef.current) : undefined;
    const playerBody = rigidBodyRef.current ? ((rigidBodyRef.current as any).raw || rigidBodyRef.current) : undefined;

    if (playerCollider) {
      if (typeof playerCollider.halfHeight === 'function') {
        halfHeight = playerCollider.halfHeight();
      } else if (typeof playerCollider.halfHeight === 'number') {
        halfHeight = playerCollider.halfHeight;
      }

      if (typeof playerCollider.radius === 'function') {
        radius = playerCollider.radius();
      } else if (typeof playerCollider.radius === 'number') {
        radius = playerCollider.radius;
      }

      if (typeof playerCollider.translation === 'function') {
        const cTrans = playerCollider.translation();
        if (cTrans && typeof cTrans.y === 'number') {
          colliderOffsetY = cTrans.y - translation.y;
        }
      }
    }

    // Dynamic bottom Y of capsule collider in world coordinates
    const colliderBottomY = translation.y + colliderOffsetY - (halfHeight + radius);

    // Ray origin starts slightly inside the collider bottom (skin width = 0.1m)
    const skinWidth = 0.1;
    const rayOriginY = colliderBottomY + skinWidth;
    const maxCastDistance = skinWidth + 0.15; // Cast 0.15m below collider bottom

    // Multi-point raycast (center + 4 cardinal points around capsule base)
    const rayOffsets = [
      { x: 0, z: 0 },
      { x: radius * 0.5, z: 0 },
      { x: -radius * 0.5, z: 0 },
      { x: 0, z: radius * 0.5 },
      { x: 0, z: -radius * 0.5 },
    ];

    let groundedByRay = false;

    for (const offset of rayOffsets) {
      _groundRayOrigin.set(translation.x + offset.x, rayOriginY, translation.z + offset.z);
      _groundRay.origin = _groundRayOrigin;
      const hit = world.castRay(_groundRay, maxCastDistance, true, undefined, undefined, playerCollider, playerBody);

      if (hit !== null && hit.timeOfImpact <= maxCastDistance) {
        groundedByRay = true;
        break;
      }
    }

    const isGrounded = groundedByRay && Math.abs(velocity.y) < 2.5;

    if (isGrounded) {
      isGroundedRef.current = true;
      hasJumpedInAirRef.current = false;
    } else {
      isGroundedRef.current = false;
    }

    // Initialize target velocities from current linear velocity
    let targetVx = velocity.x;
    let targetVy = velocity.y;
    let targetVz = velocity.z;

    // Edge-triggered Jump
    const jumpJustPressed = jumpInput && !prevJumpInputRef.current;
    prevJumpInputRef.current = jumpInput;

    if (jumpJustPressed && !isDodgingRef.current) {
      if (isGroundedRef.current) {
        targetVy = JUMP_FORCE;
        isGroundedRef.current = false;
      } else if (!hasJumpedInAirRef.current) {
        targetVy = DOUBLE_JUMP_FORCE;
        hasJumpedInAirRef.current = true;
      }
    }

    // Variable gravity: lighter while rising, heavier while falling.
    // This makes the apex feel natural and the landing feel heavier without
    // changing peak jump height.
    // Use targetVy (which includes the jump impulse) rather than the stale
    // current velocity so the first jump frame gets rising gravity, not fall.
    // Apply fall gravity when rising slowly (near apex) for a snappy transition,
    // or when actually falling. This eliminates the floaty hang at the top.
    const isRising = targetVy > C.apexThreshold;
    const gravityScale = isRising ? C.jumpGravity : C.fallGravity;
    rigidBodyRef.current.setGravityScale(gravityScale, true);

    // Slope handling: when grounded and vertical velocity is small, dampen it
    // to reduce jitter and bouncing on uneven terrain. Uses isGroundedRef
    // (not the local isGrounded) so a just-triggered jump — which sets the
    // ref to false — is not overwritten back to zero.
    if (isGroundedRef.current && Math.abs(velocity.y) < C.slopeDampThreshold) {
      targetVy = velocity.y * C.slopeDampFactor;
    }

    // Landing detection — trigger visual feedback on ground transition
    if (isGrounded && !wasGroundedRef.current) {
      const fallSpeed = Math.abs(velocity.y);
      if (fallSpeed >= C.landingMinFallSpeed) {
        landingDipRef.current = C.landingDipStrength;
        squashScaleRef.current = C.landingSquashScale;
      }
    }
    wasGroundedRef.current = isGrounded;

    // Recover landing dip and squash smoothly
    landingDipRef.current = THREE.MathUtils.lerp(landingDipRef.current, 0, Math.min(1, delta * C.landingDipSpeed));
    squashScaleRef.current = THREE.MathUtils.lerp(squashScaleRef.current, 1, Math.min(1, delta * C.landingSquashRecover));
    if (playerMeshRef.current) {
      playerMeshRef.current.scale.y = squashScaleRef.current;
    }

    // -------------------------------------------------------------
    // 2. DODGE LOGIC
    // -------------------------------------------------------------
    if (dodgeCooldownRef.current > 0) {
      dodgeCooldownRef.current -= delta;
    }

    const dodgeJustPressed = dodgeInput && !prevDodgeInputRef.current;
    prevDodgeInputRef.current = dodgeInput;

    if (dodgeJustPressed && !isDodgingRef.current && dodgeCooldownRef.current <= 0) {
      const dodgeSuccess = useGameStore.getState().triggerPlayerDodge();
      if (dodgeSuccess) {
        isDodgingRef.current = true;
        dodgeTimerRef.current = CC.dodgeDurationMs / 1000;
        dodgeCooldownRef.current = CC.dodgeCooldownSec; // Cooldown before next roll

        // Movement direction
        _v1.set(0, 0, 0);
        if (forward) _v1.z -= 1;
        if (backward) _v1.z += 1;
        if (left) _v1.x -= 1;
        if (right) _v1.x += 1;
        if (joystick.x !== 0 || joystick.y !== 0) {
          _v1.x = joystick.x;
          _v1.z = joystick.y;
        }
        
        if (_v1.lengthSq() > 0.01) {
          _v1.normalize();
          const finalX = _v1.x * Math.cos(cameraAngle) + _v1.z * Math.sin(cameraAngle);
          const finalZ = -_v1.x * Math.sin(cameraAngle) + _v1.z * Math.cos(cameraAngle);
          dodgeDirRef.current.set(finalX, 0, finalZ).normalize();
        } else {
          const rotY = playerMeshRef.current.rotation.y;
          dodgeDirRef.current.set(Math.sin(rotY), 0, Math.cos(rotY)).normalize();
        }
      }
    }

    // Handle Active Dodge Roll
    if (isDodgingRef.current) {
      dodgeTimerRef.current -= delta;
      const currentSpeed = sprintInput ? SPEED * SPRINT_MULT : SPEED;
      const dodgeSpeed = currentSpeed * CC.dodgeSpeedMultiplier;

      targetVx = dodgeDirRef.current.x * dodgeSpeed;
      targetVz = dodgeDirRef.current.z * dodgeSpeed;

      // Roll animation (360 pitch rotation)
      if (playerMeshRef.current) {
        const progress = 1 - Math.max(0, dodgeTimerRef.current / (CC.dodgeDurationMs / 1000));
        playerMeshRef.current.rotation.x = progress * Math.PI * 2;
      }

      if (dodgeTimerRef.current <= 0) {
        isDodgingRef.current = false;
        if (playerMeshRef.current) {
          playerMeshRef.current.rotation.x = 0;
        }
      }
    }

    // -------------------------------------------------------------
    // 3. ATTACK LOGIC & COMBOS
    // -------------------------------------------------------------
    const attackJustPressed = attackInput && !prevAttackInputRef.current;
    prevAttackInputRef.current = attackInput;

    // Input buffering: if attack is pressed during an active swing, remember it
    // so the next combo fires immediately when the current swing ends.
    if (attackJustPressed && !isDodgingRef.current) {
      if (attackTimerRef.current > 0) {
        // Buffer the press — will fire when current swing ends
        attackInputBufferRef.current = CC.attackInputBufferMs / 1000;
      } else {
        const comboStage = useGameStore.getState().triggerPlayerAttack();
        if (comboStage > 0) {
          attackComboStageRef.current = comboStage;
          attackTimerRef.current = CC.attackDuration;
          hitEnemiesThisSwingRef.current.clear();
          attackCamPushRef.current = CC.attackCameraPush;
          trailAlphaRef.current = 1;
          combatAudio.swing({ comboStage: comboStage as 1 | 2 | 3 });
          if (comboStage === 3) {
            useGameStore.getState().triggerCameraShake(CC.shakeLight);
          }
        }
      }
    }

    // Decay input buffer timer
    if (attackInputBufferRef.current > 0) {
      attackInputBufferRef.current -= delta;
      // If swing just ended and buffer is still valid, fire buffered attack
      if (attackTimerRef.current <= 0 && attackInputBufferRef.current > 0) {
        attackInputBufferRef.current = 0;
        const comboStage = useGameStore.getState().triggerPlayerAttack();
        if (comboStage > 0) {
          attackComboStageRef.current = comboStage;
          attackTimerRef.current = CC.attackDuration;
          hitEnemiesThisSwingRef.current.clear();
          attackCamPushRef.current = CC.attackCameraPush;
          trailAlphaRef.current = 1;
          combatAudio.swing({ comboStage: comboStage as 1 | 2 | 3 });
          if (comboStage === 3) {
            useGameStore.getState().triggerCameraShake(CC.shakeLight);
          }
        }
      }
    }

    // Handle Active Attack Swing & Hit Detection
    if (attackTimerRef.current > 0) {
      attackTimerRef.current -= effectiveDelta;
      const progress = 1 - Math.max(0, attackTimerRef.current / CC.attackDuration);

      // Animate Sword per combo stage
      if (swordGroupRef.current) {
        const stage = attackComboStageRef.current;
        if (stage === 1) {
          // Horizontal right to left slash
          swordGroupRef.current.rotation.set(0.2, -Math.PI / 2 + progress * Math.PI, -0.4);
        } else if (stage === 2) {
          // Diagonal left to right slash
          swordGroupRef.current.rotation.set(-0.5 + progress * 1.2, Math.PI / 2 - progress * Math.PI, 0.6);
        } else {
          // Stage 3: Heavy overhead chop
          swordGroupRef.current.rotation.set(-Math.PI / 1.1 + progress * Math.PI * 1.5, 0, 0);
        }
      }

      // Hit detection — runs every frame within the hit window so enemies
      // entering range mid-swing are still caught. Per-enemy tracking
      // prevents the same swing from damaging one target more than once.
      if (progress >= CC.hitDetectStart && progress <= CC.hitDetectEnd) {
        _v2.set(translation.x, translation.y, translation.z); // playerPos
        const rotY = playerMeshRef.current.rotation.y;
        _v3.set(Math.sin(rotY), 0, Math.cos(rotY)).normalize(); // facingDir

        const stage = attackComboStageRef.current;
        const damage = stage === 1 ? 15 : stage === 2 ? 25 : 45;

        // Query enemy targets
        enemyTargets.forEach((target) => {
          if (hitEnemiesThisSwingRef.current.has(target.id)) return;
          const enemyPos = target.getPosition();
          const dist = _v2.distanceTo(enemyPos);
          if (dist <= CC.attackRange) {
            _v4.copy(enemyPos).sub(_v2); // toEnemy
            _v4.y = 0;
            if (_v4.lengthSq() > 0.001) {
              _v4.normalize();
              const dot = _v3.dot(_v4);
              if (dot > CC.attackDotThreshold || dist < CC.attackCloseRange) {
                hitEnemiesThisSwingRef.current.add(target.id);
                const damageDealt = target.takeDamage(damage, _v2, stage);
                if (!damageDealt) return;
                useGameStore.getState().confirmComboHit();
                useGameStore.getState().triggerHitStop(stage === 3 ? CC.hitStopMsHeavy : CC.hitStopMs);
                useGameStore.getState().triggerCameraShake(stage === 3 ? CC.shakeHeavy : CC.shakeLight);
                useGameStore.getState().addHitSpark(enemyPos.x, enemyPos.y + 1.2, enemyPos.z, stage === 3 ? CC.hitSparkColorHeavy : CC.hitSparkColorNormal);
                // Directional slash particles — burst outward along attack direction
                useGameStore.getState().addSlashParticles(enemyPos.x, enemyPos.y + 1.0, enemyPos.z, _v3.x, _v3.z, stage === 3 ? CC.hitSparkColorHeavy : CC.slashParticleColor);
                // Weapon recoil on hit
                weaponRecoilRef.current = CC.weaponRecoilDistance;
                combatAudio.hit({ comboStage: stage as 1 | 2 | 3, enemyName: '', position: [enemyPos.x, enemyPos.y, enemyPos.z] });
              }
            }
          }
        });
      }

      if (attackTimerRef.current <= 0) {
        if (swordGroupRef.current) {
          swordGroupRef.current.rotation.set(0, 0, 0);
        }
        trailAlphaRef.current = 0;
      }
    } else {
      if (swordGroupRef.current) {
        swordGroupRef.current.rotation.set(0, 0, 0);
      }
      trailAlphaRef.current = 0;
    }

    // Weapon recoil recover
    if (weaponRecoilRef.current > 0.001) {
      weaponRecoilRef.current = THREE.MathUtils.lerp(weaponRecoilRef.current, 0, Math.min(1, delta * CC.weaponRecoilRecoverSpeed));
      if (swordGroupRef.current) {
        swordGroupRef.current.position.z = 0.2 + weaponRecoilRef.current;
      }
    } else if (swordGroupRef.current && swordGroupRef.current.position.z !== 0.2) {
      swordGroupRef.current.position.z = 0.2;
    }

    // Attack camera push recover (visual nudge forward on swing start)
    if (attackCamPushRef.current > 0.001) {
      attackCamPushRef.current = THREE.MathUtils.lerp(attackCamPushRef.current, 0, Math.min(1, delta * CC.attackCameraRecoverSpeed));
    } else {
      attackCamPushRef.current = 0;
    }

    // Weapon trail fade — visible during swing, fades quickly after
    if (trailAlphaRef.current > 0.001) {
      trailAlphaRef.current = Math.max(0, trailAlphaRef.current - delta / CC.weaponTrailLifetime);
      if (trailMeshRef.current) {
        trailMeshRef.current.visible = true;
        const mat = trailMeshRef.current.material as THREE.MeshBasicMaterial;
        mat.opacity = trailAlphaRef.current * 0.6;
        // Scale trail slightly with swing intensity
        const scale = 1 + (1 - trailAlphaRef.current) * 0.3;
        trailMeshRef.current.scale.set(scale, 1, 1);
      }
    } else if (trailMeshRef.current && trailMeshRef.current.visible) {
      trailMeshRef.current.visible = false;
    }

    // -------------------------------------------------------------
    // 4. NORMAL MOVEMENT (WHEN NOT DODGING)
    // -------------------------------------------------------------
    if (!isDodgingRef.current) {
      _v1.set(0, 0, 0);
      if (forward) _v1.z -= 1;
      if (backward) _v1.z += 1;
      if (left) _v1.x -= 1;
      if (right) _v1.x += 1;
      if (joystick.x !== 0 || joystick.y !== 0) {
        _v1.x = joystick.x;
        _v1.z = joystick.y;
      }

      if (_v1.lengthSq() > 0.01) {
        _v1.normalize();
        
        // Handle Sprint stamina consumption
        const storeState = useGameStore.getState();
        const canSprint = sprintInput && storeState.player.stamina > 2;
        if (canSprint) {
          storeState.setPlayerStamina(storeState.player.stamina - CC.sprintStaminaDrainPerSec * delta);
          storeState.recordStaminaUse();
        }

        const slowFactor = storeState.player.slowFactor ?? 1.0;
        const currentSpeed = (canSprint ? SPEED * SPRINT_MULT : SPEED) * slowFactor;
        
        // Attack slows movement slightly
        const speedMult = attackTimerRef.current > 0 ? CC.attackMoveSlow : 1.0;
        
        const desiredVx = (_v1.x * Math.cos(cameraAngle) + _v1.z * Math.sin(cameraAngle)) * currentSpeed * speedMult;
        const desiredVz = (-_v1.x * Math.sin(cameraAngle) + _v1.z * Math.cos(cameraAngle)) * currentSpeed * speedMult;

        // Frame-rate-independent acceleration toward desired velocity.
        // Air control is reduced to prevent unrealistic instant turns.
        const accelRate = isGrounded ? C.groundAccel : C.airAccel;
        const accel = Math.min(1, delta * accelRate);
        targetVx = THREE.MathUtils.lerp(velocity.x, desiredVx, accel);
        targetVz = THREE.MathUtils.lerp(velocity.z, desiredVz, accel);

        // Shortest-angle rotation towards movement direction
        const targetRotation = Math.atan2(desiredVx, desiredVz);
        const currentRotation = playerMeshRef.current.rotation.y;
        let diff = targetRotation - currentRotation;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        
        playerMeshRef.current.rotation.y = currentRotation + diff * Math.min(1, delta * ROTATION_SPEED);
      } else {
        // Damping towards 0 when no input, preserving residual knockback decay
        const decelRate = isGrounded ? C.groundDecel : C.airDecel;
        const damp = Math.min(1, delta * decelRate);
        targetVx = THREE.MathUtils.lerp(velocity.x, 0, damp);
        targetVz = THREE.MathUtils.lerp(velocity.z, 0, damp);
      }
    }

    // -------------------------------------------------------------
    // APPLY COMBINED VELOCITY (ONCE PER FRAME)
    // -------------------------------------------------------------
    rigidBodyRef.current.setLinvel({ x: targetVx, y: targetVy, z: targetVz }, true);

    // -------------------------------------------------------------
    // 5b. HEAD BOB, SPRINT FOV, FOOTSTEPS
    // -------------------------------------------------------------
    const horizontalSpeed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
    const isMoving = horizontalSpeed > 0.5 && isGrounded && !isDodgingRef.current;
    const isSprinting = sprintInput && isMoving && horizontalSpeed > SPEED * 1.1;

    // Head bob — accumulate phase while moving, reset when stopped or airborne
    if (isMoving) {
      const freq = isSprinting ? C.headBobSprintFrequency : C.headBobFrequency;
      headBobPhaseRef.current += delta * freq;
    } else {
      headBobPhaseRef.current = 0;
    }

    // Footstep cadence — accumulate distance, trigger when threshold is reached.
    // Architecture supports future material-based footsteps by swapping the
    // sound callback based on ground surface; for now it's a no-op stub.
    if (isMoving) {
      prevFootstepDistRef.current += horizontalSpeed * delta;
      const stride = isSprinting ? C.footstepSprintStride : C.footstepWalkStride;
      if (prevFootstepDistRef.current >= stride) {
        prevFootstepDistRef.current = 0;
        // Footstep sound hook — material detection would go here in the future
        // playFootstep(getGroundMaterial(translation));
      }
    } else {
      prevFootstepDistRef.current = 0;
    }

    // Sprint FOV — smooth transition in/out of sprint
    const targetFov = isSprinting ? C.baseFov + C.sprintFovIncrease : C.baseFov;
    currentFovRef.current = THREE.MathUtils.lerp(currentFovRef.current, targetFov, Math.min(1, delta * C.sprintFovLerpSpeed));
    if (camera.fov !== currentFovRef.current) {
      camera.fov = currentFovRef.current;
      camera.updateProjectionMatrix();
    }

    // -------------------------------------------------------------
    // 5. CAMERA ORBIT & FOLLOW & STORE POSITION SYNC
    // -------------------------------------------------------------
    _v1.set(translation.x, translation.y, translation.z); // targetPos
    const desiredDist: number = C.cameraDistance;
    const baseHeight: number = C.cameraHeight;
    const dirSign = cameraMode === 'second' ? -1 : 1;

    let idealCameraPos: THREE.Vector3;
    let lookTarget: THREE.Vector3;

    if (cameraMode === 'first') {
      // First person: camera at the player's head, looking forward along yaw/pitch.
      // The player's forward direction is (-sin(θ), 0, -cos(θ)) — the same
      // convention used by the movement code — so the look offset must negate
      // both horizontal and pitch to match where the player actually faces.
      const headHeight = 1.6;
      _v2.set(0, headHeight, 0); // eyeOffset
      _v4.copy(_v1).add(_v2); // idealCameraPos = targetPos + eyeOffset

      const lookAhead = 5;
      _v5.set(
        -Math.sin(cameraAngle) * Math.cos(cameraPitch) * lookAhead,
        -Math.sin(cameraPitch) * lookAhead,
        -Math.cos(cameraAngle) * Math.cos(cameraPitch) * lookAhead,
      ); // lookOffset
      _v3.copy(_v4).add(_v5); // lookTarget = idealCameraPos + lookOffset
      idealCameraPos = _v4;
      lookTarget = _v3;
    } else {
      // Third / Second person: spherical orbit with camera collision
      const horizDist = desiredDist * Math.cos(cameraPitch);
      _v2.set(
        Math.sin(cameraAngle) * horizDist * dirSign,
        baseHeight + desiredDist * Math.sin(cameraPitch),
        Math.cos(cameraAngle) * horizDist * dirSign,
      ); // orbitOffset

      _v4.copy(_v1).add(_v2); // desiredCameraPos = targetPos + orbitOffset

      // Raycast from the player's head toward the desired camera position to
      // detect obstacles. The origin must be at head height (not the feet /
      // body center) so the ray doesn't start on the floor surface and report a
      // zero-distance self-hit. solid=false treats shapes as hollow so a ray
      // starting inside a shape still reports the exit boundary.
      const camPlayerBody = (rigidBodyRef.current as any).raw || rigidBodyRef.current;
      _v3.copy(_v1).add(_v5.set(0, 1.6, 0)); // rayOrigin = targetPos + (0,1.6,0)
      _v5.copy(_v4).sub(_v3).normalize(); // rayDir
      const rayLen = Math.max(0.1, _v3.distanceTo(_v4));
      _camRay.origin = _v3;
      _camRay.dir = _v5;
      const hit = world.castRay(_camRay, rayLen, false, undefined, undefined, undefined, camPlayerBody);

      let collisionDist = desiredDist;
      if (hit !== null && hit.timeOfImpact < rayLen) {
        // Place camera just in front of the obstacle (skin width 0.4)
        collisionDist = Math.max(0.5, hit.timeOfImpact - 0.4);
      }

      // Smoothly interpolate the collision-adjusted distance (no snapping)
      const lerpFactor = Math.min(1, delta * C.cameraCollisionLerp);
      smoothedDistRef.current = THREE.MathUtils.lerp(smoothedDistRef.current, collisionDist, lerpFactor);

      // Rebuild orbit offset using the smoothed distance
      const safeHoriz = smoothedDistRef.current * Math.cos(cameraPitch);
      _v2.set(
        Math.sin(cameraAngle) * safeHoriz * dirSign,
        baseHeight + smoothedDistRef.current * Math.sin(cameraPitch),
        Math.cos(cameraAngle) * safeHoriz * dirSign,
      ); // safeOffset (reuses orbitOffset slot)
      _v4.copy(_v1).add(_v2); // idealCameraPos
      _v3.copy(_v1).add(_v5.set(0, 1, 0)); // lookTarget = targetPos + (0,1,0)
      idealCameraPos = _v4;
      lookTarget = _v3;
    }

    const posLerp = cameraMode === 'first' ? C.cameraFirstPersonLerp : C.cameraPositionLerp;
    currentCameraPos.lerp(idealCameraPos, Math.min(1, delta * posLerp));
    camera.position.copy(currentCameraPos);

    // Apply attack camera push — slight forward nudge on swing, blends smoothly
    if (attackCamPushRef.current > 0.001) {
      _v2.set(-Math.sin(cameraAngle), 0, -Math.cos(cameraAngle)); // pushDir
      camera.position.add(_v2.multiplyScalar(attackCamPushRef.current));
    }

    // Apply head bob as a vertical offset on the camera (disabled in first
    // person to avoid discomfort, disabled while airborne)
    if (isMoving && cameraMode !== 'first') {
      const amp = isSprinting ? C.headBobSprintAmplitude : C.headBobAmplitude;
      camera.position.y += Math.sin(headBobPhaseRef.current) * amp;
    }

    // Apply landing dip as a downward camera offset (visual only)
    if (landingDipRef.current > 0.001) {
      camera.position.y -= landingDipRef.current;
    }

    // Apply camera shake AFTER all other camera offsets so the lerp doesn't smooth it away
    if (localShakeRef.current > 0.001) {
      const shake = localShakeRef.current;
      camera.position.x += (Math.random() - 0.5) * shake;
      camera.position.y += (Math.random() - 0.5) * shake;
      camera.position.z += (Math.random() - 0.5) * shake;
      localShakeRef.current = THREE.MathUtils.lerp(localShakeRef.current, 0, delta * 15);
    } else {
      localShakeRef.current = 0;
    }

    const lookLerp = cameraMode === 'first' ? C.cameraFirstPersonLookLerp : C.cameraLookLerp;
    currentLookAt.lerp(lookTarget, Math.min(1, delta * lookLerp));
    camera.lookAt(currentLookAt);

    // Hide player mesh in first person to avoid seeing inside the model.
    // The sword is a sibling (not a child) so it stays visible.
    if (playerMeshRef.current) {
      playerMeshRef.current.visible = cameraMode !== 'first';
    }
    // Sync sword pivot rotation to player facing so the weapon follows
    // the character's turning. Attack swing rotations are applied on the
    // inner swordGroupRef, not the pivot, so they layer correctly.
    if (swordPivotRef.current && playerMeshRef.current) {
      swordPivotRef.current.rotation.y = playerMeshRef.current.rotation.y;
    }

    // Physics body is the single source of truth: store follows physics body
    _posTuple[0] = translation.x;
    _posTuple[1] = translation.y;
    _posTuple[2] = translation.z;
    setPlayerPosition(_posTuple);
    useGameStore.getState().checkLocationObjectives(_posTuple);
  });

  return (
    <RigidBody
      ref={rigidBodyRef}
      colliders={false}
      mass={1}
      type="dynamic"
      position={initialPlayerPosition}
      enabledRotations={[false, false, false]}
    >
      <CapsuleCollider ref={colliderRef} args={[0.5, 0.5]} position={[0, 1, 0]} />
      {/* Body + visor — hidden in first person */}
      <group ref={playerMeshRef}>
        <mesh position={[0, 1, 0]} castShadow>
          <capsuleGeometry args={[0.5, 1, 4, 16]} />
          <meshStandardMaterial color="#3b82f6" />
        </mesh>

        <mesh position={[0, 1.5, 0.4]} castShadow>
          <boxGeometry args={[0.6, 0.2, 0.3]} />
          <meshStandardMaterial color="#1e3a8a" />
        </mesh>
      </group>

      {/* Sword — sibling of playerMeshRef so it stays visible in first person.
          swordPivotRef Y rotation is synced to playerMeshRef every frame so
          the weapon follows the character's facing direction. */}
      <group ref={swordPivotRef}>
        <group ref={swordGroupRef} position={[0.5, 1.1, 0.2]}>
          {/* Blade */}
          <mesh position={[0, 0.5, 0]} castShadow>
            <boxGeometry args={[0.08, 1.1, 0.15]} />
            <meshStandardMaterial color="#e2e8f0" metalness={0.8} roughness={0.2} />
          </mesh>
          {/* Guard */}
          <mesh position={[0, 0, 0]} castShadow>
            <boxGeometry args={[0.35, 0.08, 0.15]} />
            <meshStandardMaterial color="#eab308" />
          </mesh>
          {/* Handle */}
          <mesh position={[0, -0.2, 0]} castShadow>
            <cylinderGeometry args={[0.04, 0.04, 0.3]} />
            <meshStandardMaterial color="#78350f" />
          </mesh>
          {/* Weapon trail — lightweight plane that follows the blade tip */}
          <mesh ref={trailMeshRef} position={[0, 0.5, 0]} visible={false}>
            <planeGeometry args={[0.12, 1.0]} />
            <meshBasicMaterial color={CC.weaponTrailColor} transparent opacity={0} depthWrite={false} />
          </mesh>
        </group>
      </group>
    </RigidBody>
  );
}
