'use client';

import { Suspense, useMemo } from 'react';
import { Canvas } from '@react-three/fiber';
import { Physics, RigidBody, CuboidCollider } from '@react-three/rapier';
import { KeyboardControls, Sky, Html } from '@react-three/drei';
import Player from './Player';
import { useGameStore } from '@/lib/store';
import SlimeEnemy from './enemies/SlimeEnemy';
import WolfEnemy from './enemies/WolfEnemy';
import BanditEnemy from './enemies/BanditEnemy';
import MageEnemy from './enemies/MageEnemy';
import Checkpoint from './Checkpoint';
import NPC from './NPC';
import { NPCS_DATA } from '@/lib/questData';
import EncounterArea from './EncounterArea';
import EnemyDummy from './EnemyDummy';
import WorldFX from './WorldFX';

export default function GameScene() {
  const worldPaused = useGameStore((state) => state.ui.showSettings || state.ui.showInventory || state.hudEditMode);
  const shadowsEnabled = useGameStore((state) => state.settings.shadows);
  const keyboardMap = useMemo(() => [
    { name: 'forward', keys: ['ArrowUp', 'KeyW'] },
    { name: 'backward', keys: ['ArrowDown', 'KeyS'] },
    { name: 'left', keys: ['ArrowLeft', 'KeyA'] },
    { name: 'right', keys: ['ArrowRight', 'KeyD'] },
    { name: 'jump', keys: ['Space'] },
    { name: 'sprint', keys: ['Shift'] },
    { name: 'attack', keys: ['KeyJ', 'Click'] },
    { name: 'dodge', keys: ['KeyK'] },
    { name: 'interact', keys: ['KeyE'] },
  ], []);

  return (
    <div className="absolute inset-0 z-0">
      <KeyboardControls map={keyboardMap}>
        <Canvas shadows={shadowsEnabled} camera={{ position: [0, 5, 10], fov: 60 }} frameloop={worldPaused ? 'never' : 'always'}>
          <color attach="background" args={['#87CEEB']} />
          <ambientLight intensity={0.5} />
          <directionalLight
            castShadow={shadowsEnabled}
            position={[10, 20, 10]}
            intensity={1.5}
            shadow-mapSize={[1024, 1024]}
            shadow-camera-left={-20}
            shadow-camera-right={20}
            shadow-camera-top={20}
            shadow-camera-bottom={-20}
          />
          <Sky sunPosition={[10, 20, 10]} />
          
          <Suspense fallback={null}>
            <Physics>
              <Player />
              
              {/* Checkpoints */}
              <Checkpoint position={[0, 0, 3]} name="Town Haven Checkpoint" />
              <Checkpoint position={[15, 0, -15]} name="Wilderness Outpost Checkpoint" />

              {/* NPCs */}
              {NPCS_DATA.map((npc) => (
                <NPC key={npc.id} data={npc} />
              ))}

              {/* Ancient Ruins Landmark */}
              <group position={[-20, 0, -20]}>
                <RigidBody type="fixed">
                  <mesh position={[0, 3, 0]} castShadow receiveShadow>
                    <cylinderGeometry args={[2, 2.5, 6, 8]} />
                    <meshStandardMaterial color="#475569" roughness={0.8} />
                  </mesh>
                  <mesh position={[-4, 2, -2]} castShadow receiveShadow>
                    <boxGeometry args={[1.5, 4, 1.5]} />
                    <meshStandardMaterial color="#334155" roughness={0.9} />
                  </mesh>
                  <mesh position={[4, 2, 2]} castShadow receiveShadow>
                    <boxGeometry args={[1.5, 4, 1.5]} />
                    <meshStandardMaterial color="#334155" roughness={0.9} />
                  </mesh>
                </RigidBody>
                <Html position={[0, 6.5, 0]} center distanceFactor={15}>
                  <div className="bg-purple-950/80 text-purple-200 border border-purple-500/50 px-2.5 py-1 rounded-lg text-xs font-bold shadow-xl animate-pulse">
                    🏛️ Ancient Ruins
                  </div>
                </Html>
              </group>

              {/* Target Dummies / Enemies */}
              <EnemyDummy position={[0, 0, -8]} name="Training Dummy" color="#ef4444" />
              <SlimeEnemy position={[-8, 0, -5]} name="Bouncy Slime" />
              <WolfEnemy position={[10, 0, -10]} name="Dire Wolf" />
              <BanditEnemy position={[8, 0, 8]} name="Bandit Fighter" />
              <MageEnemy position={[-12, 0, 10]} name="Arcane Mage" />

              {/* Encounter Arena */}
              <EncounterArea />

              {/* World FX */}
              <WorldFX />

              {/* Floor */}
              <RigidBody type="fixed" colliders={false}>
                <CuboidCollider args={[50, 0.5, 50]} position={[0, -0.5, 0]} />
                <mesh position={[0, -0.5, 0]} receiveShadow>
                  <boxGeometry args={[100, 1, 100]} />
                  <meshStandardMaterial color="#4ade80" />
                </mesh>
              </RigidBody>

              {/* Village / Objects */}
              <RigidBody type="fixed" position={[5, 0, -5]}>
                <mesh receiveShadow castShadow position={[0, 2, 0]}>
                  <boxGeometry args={[4, 4, 4]} />
                  <meshStandardMaterial color="#b45309" />
                </mesh>
              </RigidBody>

              <RigidBody type="fixed" position={[-8, 0, -10]}>
                <mesh receiveShadow castShadow position={[0, 1.5, 0]}>
                  <boxGeometry args={[3, 3, 3]} />
                  <meshStandardMaterial color="#b45309" />
                </mesh>
              </RigidBody>

              {/* Walls/Boundaries */}
              <RigidBody type="fixed" position={[0, 0, -50]}>
                <mesh receiveShadow>
                  <boxGeometry args={[100, 10, 1]} />
                  <meshStandardMaterial color="#1e293b" />
                </mesh>
              </RigidBody>
              <RigidBody type="fixed" position={[0, 0, 50]}>
                <mesh receiveShadow>
                  <boxGeometry args={[100, 10, 1]} />
                  <meshStandardMaterial color="#1e293b" />
                </mesh>
              </RigidBody>
              <RigidBody type="fixed" position={[-50, 0, 0]}>
                <mesh receiveShadow>
                  <boxGeometry args={[1, 10, 100]} />
                  <meshStandardMaterial color="#1e293b" />
                </mesh>
              </RigidBody>
              <RigidBody type="fixed" position={[50, 0, 0]}>
                <mesh receiveShadow>
                  <boxGeometry args={[1, 10, 100]} />
                  <meshStandardMaterial color="#1e293b" />
                </mesh>
              </RigidBody>

            </Physics>
          </Suspense>
        </Canvas>
      </KeyboardControls>
    </div>
  );
}
