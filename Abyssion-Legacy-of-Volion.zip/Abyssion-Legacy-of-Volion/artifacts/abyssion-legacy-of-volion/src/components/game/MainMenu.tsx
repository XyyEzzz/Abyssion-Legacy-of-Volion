'use client';

import { useState } from 'react';
import { SaveSlotId, SaveSlotSummary, useGameStore } from '@/lib/store';
import SettingsModal from './SettingsModal';
import CreditsScreen from './CreditsScreen';

type MenuView = 'main' | 'credits' | 'continue-slots' | 'new-slots';
type SlotPickerMode = 'continue' | 'new';

function formatSavedAt(timestamp: number | null) {
  if (!timestamp) return 'NO RECORD';
  return new Date(timestamp).toLocaleString(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}

function SaveSlotPicker({
  mode,
  slots,
  activeSlot,
  onBack,
}: {
  mode: SlotPickerMode;
  slots: SaveSlotSummary[];
  activeSlot: SaveSlotId;
  onBack: () => void;
}) {
  const continueGame = useGameStore(s => s.continueGame);
  const startNewGame = useGameStore(s => s.startNewGame);
  const [error, setError] = useState<string | null>(null);

  const chooseSlot = (slot: SaveSlotSummary) => {
    const ok = mode === 'continue'
      ? continueGame(slot.id)
      : startNewGame(slot.id);

    if (!ok) {
      setError(mode === 'continue'
        ? 'This save is unavailable. Choose another occupied slot.'
        : 'New journeys can only begin in empty slots.');
    }
  };

  const isSelectable = (slot: SaveSlotSummary) =>
    mode === 'continue' ? slot.status === 'occupied' : slot.status === 'empty';

  return (
    <div className="fixed inset-0 z-[90] overflow-hidden bg-[#0a0a0a] text-white">
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse at 35% 35%, rgba(80,12,12,0.2) 0%, transparent 52%),' +
            'radial-gradient(ellipse at 70% 70%, rgba(20,20,40,0.16) 0%, transparent 58%),' +
            '#0a0a0a',
        }}
      />
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent 0px, transparent 2px, rgba(255,255,255,0.1) 2px, rgba(255,255,255,0.1) 3px)',
        }}
      />

      <div className="relative z-10 flex h-full flex-col overflow-y-auto px-6 py-8 sm:px-10 sm:py-12 lg:px-16">
        <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.25em] text-gray-600">
          <span>SYS / SAVE ARCHIVE</span>
          <span>REV / 01</span>
        </div>

        <div className="mx-auto flex w-full max-w-2xl flex-1 flex-col justify-center py-10">
          <div className="mb-8">
            <div className="mb-3 flex items-center gap-3">
              <div className="h-[2px] w-8 bg-[#e61919]" />
              <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-gray-500">
                {mode === 'continue' ? 'Resume journey' : 'Begin journey'}
              </span>
            </div>
            <h1 className="text-3xl font-black uppercase tracking-tight text-white sm:text-5xl">
              Select Save Slot
            </h1>
            <p className="mt-3 max-w-lg font-mono text-[10px] uppercase leading-relaxed tracking-[0.18em] text-gray-500 sm:text-xs">
              {mode === 'continue'
                ? 'Choose an occupied archive to continue. Empty and corrupted records are locked.'
                : 'Choose an empty archive. Occupied records are protected from replacement.'}
            </p>
          </div>

          <div className="grid gap-2">
            {slots.map((slot) => {
              const selectable = isSelectable(slot);
              const isActive = slot.id === activeSlot;
              const statusText = slot.status === 'occupied'
                ? 'OCCUPIED'
                : slot.status === 'corrupted'
                  ? 'CORRUPTED'
                  : 'EMPTY';

              return (
                <button
                  key={slot.id}
                  type="button"
                  disabled={!selectable}
                  onClick={() => chooseSlot(slot)}
                  className={`group flex w-full items-center gap-4 border-l-2 px-4 py-4 text-left transition-all ${
                    selectable
                      ? 'border-gray-700 bg-black/45 hover:border-[#e61919] hover:bg-black/65 active:translate-x-1'
                      : 'cursor-not-allowed border-gray-800 bg-black/25 opacity-60'
                  }`}
                >
                  <span className={`font-mono text-2xl font-bold tabular-nums ${selectable ? 'text-gray-300 group-hover:text-white' : 'text-gray-700'}`}>
                    0{slot.id}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className={`block font-black uppercase tracking-wider ${selectable ? 'text-gray-200 group-hover:text-white' : 'text-gray-600'}`}>
                      {statusText}
                      {isActive && slot.status === 'occupied' && (
                        <span className="ml-2 font-mono text-[9px] font-normal tracking-[0.2em] text-[#e61919]">
                          ACTIVE
                        </span>
                      )}
                    </span>
                    <span className="mt-1 block truncate font-mono text-[9px] uppercase tracking-[0.12em] text-gray-600">
                      {slot.status === 'occupied'
                        ? `Last saved ${formatSavedAt(slot.savedAt)}`
                        : slot.status === 'corrupted'
                          ? 'Cannot be loaded or replaced'
                          : 'Available for a new journey'}
                    </span>
                  </span>
                  <span className="hidden text-right sm:block">
                    <span className="block font-mono text-[9px] uppercase tracking-[0.15em] text-gray-600">
                      {slot.playerLevel !== null ? `LEVEL ${slot.playerLevel}` : '—'}
                    </span>
                    <span className="mt-1 block font-mono text-[9px] uppercase tracking-[0.15em] text-gray-700">
                      {selectable ? 'SELECT' : 'LOCKED'}
                    </span>
                  </span>
                  {selectable && (
                    <span className="font-mono text-sm text-gray-600 transition-colors group-hover:text-[#e61919]">
                      &gt;&gt;
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {error && (
            <p className="mt-4 border-l-2 border-[#e61919] bg-[#e61919]/5 px-3 py-2 font-mono text-[10px] uppercase tracking-[0.12em] text-[#f87171]">
              {error}
            </p>
          )}

          {mode === 'continue' && !slots.some((slot) => slot.status === 'occupied') && (
            <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.12em] text-gray-600">
              No valid saves found. Return and begin a new journey.
            </p>
          )}
          {mode === 'new' && !slots.some((slot) => slot.status === 'empty') && (
            <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.12em] text-gray-600">
              All archives are occupied or corrupted. No record was replaced.
            </p>
          )}
        </div>

        <button
          type="button"
          onClick={onBack}
          className="mx-auto w-full max-w-2xl border-l-2 border-gray-800 bg-black/30 px-4 py-3 text-left font-black uppercase tracking-wider text-gray-500 transition-colors hover:border-gray-500 hover:text-white"
        >
          <span className="mr-3 font-mono text-sm text-gray-700">&lt;&lt;</span>
          Back to Main Menu
        </button>
      </div>
    </div>
  );
}

export default function MainMenu() {
  const saveSlots = useGameStore(s => s.saveSlots);
  const activeSlot = useGameStore(s => s.activeSlot);
  const showSettings = useGameStore(s => s.ui.showSettings);
  const setShowSettings = useGameStore(s => s.setShowSettings);
  const [view, setView] = useState<MenuView>('main');

  if (showSettings) return <SettingsModal />;
  if (view === 'credits') return <CreditsScreen onBack={() => setView('main')} />;
  if (view === 'continue-slots') {
    return (
      <SaveSlotPicker
        mode="continue"
        slots={saveSlots}
        activeSlot={activeSlot}
        onBack={() => setView('main')}
      />
    );
  }
  if (view === 'new-slots') {
    return (
      <SaveSlotPicker
        mode="new"
        slots={saveSlots}
        activeSlot={activeSlot}
        onBack={() => setView('main')}
      />
    );
  }

  const hasSaveData = saveSlots.some((slot) => slot.status === 'occupied');

  const menuItems: { label: string; sublabel: string; action: () => void; disabled?: boolean; danger?: boolean }[] = [
    {
      label: 'CONTINUE',
      sublabel: hasSaveData ? 'SELECT A SAVE SLOT' : 'NO SAVE DATA FOUND',
      action: () => setView('continue-slots'),
      disabled: !hasSaveData,
    },
    {
      label: 'NEW GAME',
      sublabel: 'BEGIN A NEW JOURNEY',
      action: () => setView('new-slots'),
    },
    {
      label: 'SETTINGS',
      sublabel: 'SYSTEM CONFIGURATION',
      action: () => setShowSettings(true),
    },
    {
      label: 'CREDITS',
      sublabel: 'DEVELOPMENT TEAM',
      action: () => setView('credits'),
    },
  ];

  return (
    <div className="fixed inset-0 z-[90] bg-[#0a0a0a] overflow-hidden">
      {/* Dark fantasy background — layered radial gradients on dark substrate */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse at 30% 40%, rgba(80,12,12,0.18) 0%, transparent 50%),' +
            'radial-gradient(ellipse at 70% 60%, rgba(20,20,40,0.15) 0%, transparent 55%),' +
            'radial-gradient(circle at 50% 100%, rgba(230,25,25,0.06) 0%, transparent 40%),' +
            '#0a0a0a',
        }}
      />
      {/* Scanline texture */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent 0px, transparent 2px, rgba(255,255,255,0.1) 2px, rgba(255,255,255,0.1) 3px)',
        }}
      />
      {/* Vignette */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />

      {/* Corner technical markers */}
      <div className="absolute top-3 left-3 font-mono text-gray-600 text-[10px] uppercase tracking-wider z-10">
        SYS / MENU
      </div>
      <div className="absolute top-3 right-3 font-mono text-gray-600 text-[10px] uppercase tracking-wider z-10">
        REV / 01
      </div>

      {/* Main layout — title left, menu right on desktop; stacked on mobile */}
      <div className="relative z-10 w-full h-full flex flex-col">
        {/* Title area */}
        <div className="flex-1 flex flex-col justify-center px-6 sm:px-10 lg:px-16 max-w-xl">
          <h1
            className="font-black text-white uppercase leading-[0.85] tracking-tight"
            style={{
              fontSize: 'clamp(3rem, 10vw, 8rem)',
              textShadow: '0 4px 24px rgba(0,0,0,0.9)',
            }}
          >
            ABYSSION
          </h1>
          <div className="mt-3 flex items-center gap-3">
            <div className="h-[2px] w-8 bg-[#e61919]" />
            <span
              className="font-mono uppercase tracking-[0.3em] text-gray-300"
              style={{ fontSize: 'clamp(0.55rem, 1.6vw, 0.85rem)' }}
            >
              Legacy of Volion
            </span>
          </div>
          <p
            className="mt-6 text-gray-400 max-w-sm leading-relaxed"
            style={{ fontSize: 'clamp(0.7rem, 2vw, 0.9rem)' }}
          >
            The Abyss stirs beneath Volion. Take up the blade and descend into a world of shadow, steel, and forgotten legacy.
          </p>
        </div>

        {/* Menu items — bottom right on desktop, full width bottom on mobile */}
        <div className="flex justify-end px-6 sm:px-10 lg:px-16 pb-8 sm:pb-12">
          <nav className="w-full max-w-xs flex flex-col gap-[2px]">
            {menuItems.map((item) => (
              <button
                key={item.label}
                disabled={item.disabled}
                onClick={item.action}
                className={`group relative flex items-center justify-between px-4 py-3 border-l-2 transition-all duration-150 text-left ${
                  item.disabled
                    ? 'border-gray-800 bg-black/30 cursor-not-allowed'
                    : 'border-gray-700 bg-black/40 hover:border-[#e61919] hover:bg-black/60 active:translate-x-1'
                }`}
              >
                <div className="flex flex-col gap-0.5">
                  <span
                    className={`font-black uppercase tracking-wider transition-colors ${
                      item.disabled
                        ? 'text-gray-700'
                        : 'text-gray-200 group-hover:text-white'
                    }`}
                    style={{ fontSize: 'clamp(0.85rem, 2.5vw, 1.05rem)' }}
                  >
                    {item.label}
                  </span>
                  <span
                    className={`font-mono uppercase tracking-wider ${
                      item.disabled ? 'text-gray-800' : 'text-gray-500 group-hover:text-gray-400'
                    }`}
                    style={{ fontSize: 'clamp(0.45rem, 1.3vw, 0.65rem)' }}
                  >
                    {item.sublabel}
                  </span>
                </div>
                {!item.disabled && (
                  <span className="font-mono text-gray-600 group-hover:text-[#e61919] transition-colors text-sm">
                    &gt;&gt;
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>
      </div>
    </div>
  );
}
