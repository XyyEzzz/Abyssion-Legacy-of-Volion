'use client';

import { ChevronLeft } from 'lucide-react';

const FOUNDERS = [
  { role: 'Founder / Lead Developer', name: 'EZROHELL' },
  { role: 'Co-Founder / Technical Support', name: 'VALZ' },
];

const SPECIAL_THANKS = [
  'Our Testers',
  'Our Early Alpha Players',
  'Playtesters & Feedback Contributors',
  'Friends & Community',
  'Everyone who contributed development feedback',
];

const PRODUCTION_CREDITS = [
  { department: 'GAME DIRECTION & DESIGN', name: 'EZROHELL' },
  { department: 'PROGRAMMING & SYSTEMS DESIGN', name: 'EZROHELL' },
  { department: 'ART & VISUAL DIRECTION', name: 'EZROHELL' },
  { department: 'WORLD & LEVEL DESIGN', name: 'EZROHELL' },
  { department: 'WRITING & NARRATIVE DESIGN', name: 'EZROHELL' },
  { department: 'AUDIO & SOUND DESIGN', name: 'EZROHELL' },
  { department: 'ANIMATION & UI/UX', name: 'EZROHELL' },
  { department: 'TECHNICAL SUPPORT', name: 'VALZ' },
];

const TECHNOLOGY_STACK = [
  'Next.js / React',
  'Three.js / React Three Fiber',
  'Rapier Physics',
  'Zustand State Management',
];

interface CreditsScreenProps {
  onBack: () => void;
}

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-7 flex items-center gap-3">
      <span className="h-2 w-2 shrink-0 bg-[#e61919] shadow-[0_0_12px_rgba(230,25,25,0.75)]" />
      <h2 className="font-mono text-xs font-bold uppercase tracking-[0.28em] text-[#f04444]">
        {children}
      </h2>
      <div className="h-px flex-1 bg-gradient-to-r from-[#e61919]/50 to-transparent" />
    </div>
  );
}

function CreditsSection({
  children,
  className = '',
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={`border-t border-white/10 pt-10 ${className}`}>
      {children}
    </section>
  );
}

export default function CreditsScreen({ onBack }: CreditsScreenProps) {
  return (
    <div className="fixed inset-0 z-[95] overflow-y-auto bg-[#090909] text-white">
      {/* Industrial background treatment */}
      <div
        className="pointer-events-none fixed inset-0 opacity-40"
        style={{
          background:
            'radial-gradient(ellipse at 20% 0%, rgba(124, 15, 15, 0.24), transparent 48%),' +
            'radial-gradient(ellipse at 90% 70%, rgba(35, 38, 55, 0.18), transparent 52%),' +
            'linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px),' +
            'linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px)',
          backgroundSize: 'auto, auto, 42px 42px, 42px 42px',
        }}
      />
      <div className="pointer-events-none fixed inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/80" />

      {/* Technical markers */}
      <div className="pointer-events-none fixed left-3 top-3 z-10 font-mono text-[10px] uppercase tracking-wider text-gray-700">
        SYS / CREDITS
      </div>
      <div className="pointer-events-none fixed right-3 top-3 z-10 font-mono text-[10px] uppercase tracking-wider text-gray-700">
        REV / 01
      </div>

      {/* Back button — navigation behavior is supplied by MainMenu */}
      <button
        onClick={onBack}
        className="fixed right-5 top-5 z-20 flex items-center gap-2 border border-gray-700 bg-black/70 px-3 py-2 text-gray-400 backdrop-blur-sm transition-colors hover:border-[#e61919] hover:text-white sm:right-8 sm:top-7"
      >
        <ChevronLeft size={16} />
        <span className="font-mono text-xs uppercase tracking-wider">BACK</span>
      </button>

      <main className="relative mx-auto w-full max-w-5xl px-5 pb-20 pt-24 sm:px-10 sm:pt-28">
        {/* Title lockup */}
        <header className="border-b border-white/15 pb-12 sm:pb-16">
          <div className="mb-6 flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.35em] text-gray-500">
            <span className="h-px w-10 bg-[#e61919]" />
            CREDITS
            <span className="h-px w-10 bg-[#e61919]" />
          </div>

          <h1
            className="max-w-4xl font-black uppercase leading-[0.86] tracking-[-0.055em] text-white"
            style={{ fontSize: 'clamp(2.65rem, 9vw, 7.5rem)' }}
          >
            ABYSSION:
            <br />
            LEGACY OF VOLION
          </h1>
          <p className="mt-5 font-mono text-xs uppercase tracking-[0.35em] text-gray-500 sm:text-sm">
            (ABYSSION: LoV)
          </p>

          <div className="mt-12 grid gap-8 sm:grid-cols-[1fr_auto] sm:items-end">
            <div>
              <p className="mb-2 font-mono text-[10px] font-bold uppercase tracking-[0.28em] text-[#e61919]">
                DEVELOPED BY
              </p>
              <p className="text-2xl font-black uppercase tracking-tight text-gray-100 sm:text-3xl">
                EZROBYTE STUDIOS
              </p>
            </div>
            <div className="border-l border-[#e61919]/70 pl-5 sm:min-w-[250px]">
              <p className="mb-2 font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-gray-500">
                EST. 29 JULY 2026
              </p>
              <div className="h-1 w-24 bg-[#e61919]" />
            </div>
          </div>
        </header>

        <div className="space-y-10">
          <CreditsSection className="pt-12">
            <SectionHeading>STUDIO FOUNDERS</SectionHeading>
            <div className="grid gap-3 sm:grid-cols-2">
              {FOUNDERS.map((founder) => (
                <div
                  key={founder.role}
                  className="border border-white/10 bg-white/[0.035] px-5 py-5"
                >
                  <p className="font-mono text-[10px] uppercase leading-relaxed tracking-[0.13em] text-gray-500">
                    {founder.role}
                  </p>
                  <p className="mt-2 text-xl font-black uppercase tracking-tight text-gray-100">
                    {founder.name}
                  </p>
                </div>
              ))}
            </div>
          </CreditsSection>

          <CreditsSection>
            <SectionHeading>SPECIAL THANKS TO</SectionHeading>
            <div className="grid gap-x-10 gap-y-3 sm:grid-cols-2">
              {SPECIAL_THANKS.map((thanks) => (
                <p
                  key={thanks}
                  className="border-l-2 border-gray-700 pl-4 text-sm font-medium leading-relaxed text-gray-300 sm:text-base"
                >
                  {thanks}
                </p>
              ))}
            </div>
          </CreditsSection>

          <CreditsSection>
            <SectionHeading>GAME PRODUCTION</SectionHeading>
            <div className="grid gap-x-10 gap-y-8 sm:grid-cols-2 lg:grid-cols-3">
              {PRODUCTION_CREDITS.map((credit) => (
                <div key={credit.department}>
                  <p className="font-mono text-[10px] font-bold leading-relaxed tracking-[0.12em] text-gray-500">
                    {credit.department}
                  </p>
                  <p className="mt-2 text-lg font-black uppercase tracking-tight text-gray-100">
                    {credit.name}
                  </p>
                </div>
              ))}
            </div>
          </CreditsSection>

          <CreditsSection>
            <SectionHeading>TECHNOLOGY STACK</SectionHeading>
            <div className="grid gap-3 sm:grid-cols-2">
              {TECHNOLOGY_STACK.map((technology, index) => (
                <div
                  key={technology}
                  className="flex items-center gap-4 border-b border-white/10 pb-3"
                >
                  <span className="font-mono text-[10px] text-[#e61919]">
                    0{index + 1}
                  </span>
                  <p className="text-sm font-semibold text-gray-200 sm:text-base">
                    {technology}
                  </p>
                </div>
              ))}
            </div>
          </CreditsSection>

          <CreditsSection>
            <SectionHeading>DEVELOPMENT TOOLS &amp; AI ASSISTANCE</SectionHeading>
            <div className="border border-white/10 bg-black/20 p-5 sm:p-7">
              <p className="font-mono text-xs leading-loose tracking-[0.08em] text-gray-200 sm:text-sm">
                Google AI Studio | Bolt | Replit | FreeBuff | ChatGPT | Claude | Gemini
              </p>
              <div className="my-6 h-px bg-white/10" />
              <div className="space-y-4 text-sm leading-relaxed text-gray-400 sm:text-base">
                <p>
                  AI tools were used as development assistants for
                  <br className="hidden sm:block" /> research, ideation,
                  debugging, documentation,
                  <br className="hidden sm:block" /> and technical guidance.
                </p>
                <p>
                  Final creative, technical, and development decisions
                  <br className="hidden sm:block" /> remain with the Abyssion
                  development team.
                </p>
              </div>
            </div>
          </CreditsSection>
        </div>

        {/* Closing title card */}
        <footer className="mt-16 border-t border-[#e61919]/50 pt-10 text-center sm:mt-24">
          <p className="font-black uppercase tracking-[0.12em] text-gray-100 sm:text-xl">
            ABYSSION: LEGACY OF VOLION
          </p>
          <div className="mx-auto mt-4 h-px w-16 bg-[#e61919]" />
          <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.35em] text-gray-500">
            EST. 29 JULY 2026
          </p>
        </footer>
      </main>
    </div>
  );
}