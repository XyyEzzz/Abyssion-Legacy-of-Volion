'use client';

import { useGameStore } from '@/lib/store';
import { HudElementId, HUD_ELEMENT_LABELS, DRAGGABLE_HUD_ELEMENTS } from '@/lib/hudConfig';
import { DraggableHudElement, HudElementContent } from './GameHUD';
import { useState, useCallback } from 'react';
import { RotateCcw, Check, Eye, EyeOff } from 'lucide-react';

export default function HudEditor() {
  const hudLayout = useGameStore(s => s.hudLayout);
  const setHudElement = useGameStore(s => s.setHudElement);
  const resetHudElement = useGameStore(s => s.resetHudElement);
  const resetHudLayout = useGameStore(s => s.resetHudLayout);
  const setHudEditMode = useGameStore(s => s.setHudEditMode);
  const saveGame = useGameStore(s => s.saveGame);
  const [selectedId, setSelectedId] = useState<HudElementId | null>(null);

  const elementIds = Object.keys(HUD_ELEMENT_LABELS) as HudElementId[];

  const handleDone = useCallback(() => {
    saveGame();
    setHudEditMode(false);
  }, [saveGame, setHudEditMode]);

  const sliderRow = (label: string, value: number, min: number, max: number, onChange: (v: number) => void) => (
    <div className="flex items-center gap-2">
      <span className="text-xs text-gray-400 w-20 shrink-0">{label}</span>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="flex-1 accent-yellow-500 h-1.5"
      />
      <span className="text-xs text-gray-200 tabular-nums w-10 text-right">{value}%</span>
    </div>
  );

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-gray-950">
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800 bg-gray-900">
        <div className="flex items-center gap-2">
          <span className="text-lg font-black uppercase tracking-widest text-yellow-400">HUD Editor</span>
          <span className="text-xs text-gray-500 hidden sm:inline">Drag elements to reposition · Click to select</span>
        </div>
        <button
          onClick={handleDone}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold bg-yellow-500 hover:bg-yellow-400 text-gray-900 transition-colors"
        >
          <Check size={16} />
          Done
        </button>
      </div>

      {/* Main area: editor canvas + side panel */}
      <div className="flex-1 flex overflow-hidden">
        {/* Editor canvas — clean background, no gameplay scene */}
        <div className="flex-1 relative bg-gradient-to-br from-gray-900 via-gray-950 to-black overflow-hidden">
          {/* Grid pattern for spatial reference */}
          <div
            className="absolute inset-0 opacity-[0.04]"
            style={{
              backgroundImage: 'linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)',
              backgroundSize: '40px 40px',
            }}
          />

          {/* Aspect ratio guide — centered container matching typical game viewport */}
          <div className="absolute inset-4 sm:inset-8 rounded-lg border border-gray-800/50 overflow-hidden">
            {/* Render all HUD elements in edit mode */}
            {elementIds.map((id) => {
              const config = hudLayout[id];
              if (!config.visible) return null;
              const Content = HudElementContent[id];
              return (
                <DraggableHudElement
                  key={id}
                  id={id}
                  config={config}
                  editable
                  fullscreen={id === 'deathOverlay'}
                  selected={selectedId === id}
                  onSelect={() => setSelectedId(id)}
                >
                  <Content />
                </DraggableHudElement>
              );
            })}

            {/* Empty-state hint when nothing selected */}
            {!selectedId && (
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                <p className="text-sm text-gray-600 text-center">
                  Click any HUD element to select and customize it
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Side panel */}
        <div className="w-72 sm:w-80 border-l border-gray-800 bg-gray-900 flex flex-col overflow-hidden">
          {/* Element list */}
          <div className="p-4 border-b border-gray-800">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Elements</h3>
            <div className="space-y-1 max-h-[30vh] overflow-y-auto">
              {elementIds.map((id) => {
                const config = hudLayout[id];
                const isSelected = selectedId === id;
                return (
                  <div
                    key={id}
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors ${
                      isSelected ? 'bg-yellow-500/15 border border-yellow-500/40' : 'hover:bg-gray-800 border border-transparent'
                    }`}
                    onClick={() => setSelectedId(id)}
                  >
                    <span className={`text-sm ${isSelected ? 'text-yellow-300' : 'text-gray-300'}`}>
                      {HUD_ELEMENT_LABELS[id]}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setHudElement(id, { visible: !config.visible });
                      }}
                      className="text-gray-500 hover:text-gray-300 transition-colors"
                      title={config.visible ? 'Hide' : 'Show'}
                    >
                      {config.visible ? <Eye size={14} /> : <EyeOff size={14} />}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected element controls */}
          <div className="flex-1 p-4 overflow-y-auto">
            {selectedId ? (
              <>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold text-yellow-300">
                    {HUD_ELEMENT_LABELS[selectedId]}
                  </h3>
                  <button
                    onClick={() => resetHudElement(selectedId)}
                    className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700 transition-colors"
                    title="Reset this element"
                  >
                    <RotateCcw size={11} />
                    Reset
                  </button>
                </div>

                <div className="space-y-3">
                  {sliderRow('Size', hudLayout[selectedId].size, 50, 200, (v) => setHudElement(selectedId, { size: v }))}
                  {sliderRow('Opacity', hudLayout[selectedId].opacity, 0, 100, (v) => setHudElement(selectedId, { opacity: v }))}

                  {DRAGGABLE_HUD_ELEMENTS.includes(selectedId) && (
                    <div className="flex items-center gap-2 pt-1">
                      <span className="text-xs text-gray-400 w-20 shrink-0">Position</span>
                      <span className="text-xs text-gray-300 tabular-nums">
                        {(hudLayout[selectedId].position.x * 100).toFixed(0)}, {(hudLayout[selectedId].position.y * 100).toFixed(0)}
                      </span>
                      <span className="text-xs text-yellow-400/60 ml-auto">Drag to move</span>
                    </div>
                  )}

                  {selectedId === 'deathOverlay' && (
                    <p className="text-xs text-gray-500 pt-1">
                      Death overlay is fullscreen — only opacity and visibility can be customized.
                    </p>
                  )}
                </div>
              </>
            ) : (
              <p className="text-sm text-gray-500 text-center pt-4">
                Select an element to customize its size, opacity, and position.
              </p>
            )}
          </div>

          {/* Bottom actions */}
          <div className="p-4 border-t border-gray-800 space-y-2">
            <button
              onClick={() => resetHudLayout()}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700 transition-colors"
            >
              <RotateCcw size={12} />
              Reset All HUD
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
