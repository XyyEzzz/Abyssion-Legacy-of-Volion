'use client';

import { useGameStore } from '@/lib/store';
import { getItem, RARITY_COLORS, ItemDef, ItemType } from '@/lib/items';
import {
  splitStack,
  moveItemWithinCategory,
  getCategoryDisplaySlots,
  getActiveCategories,
  getItemCount,
  getOccupiedSlots,
  InventorySlot,
  SortMode,
  CATEGORY_META,
} from '@/lib/inventory';
import { X, Search, ChevronDown, ArrowUpDown, Package } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { useState, useCallback, useRef, useEffect, useMemo } from 'react';

const HEALING_ITEM_IDS = ['health_potion', 'small_potion', 'bread', 'apple'];

const SORT_MODES: { key: SortMode; label: string }[] = [
  { key: 'rarity', label: 'Rarity' },
  { key: 'name', label: 'Name' },
];

const RARITY_GLOW: Record<string, string> = {
  common: 'shadow-[0_0_6px_rgba(156,163,175,0.3)]',
  uncommon: 'shadow-[0_0_8px_rgba(34,197,94,0.35)]',
  rare: 'shadow-[0_0_8px_rgba(59,130,246,0.4)]',
  epic: 'shadow-[0_0_10px_rgba(168,85,247,0.4)]',
  legendary: 'shadow-[0_0_12px_rgba(245,158,11,0.5)]',
};

type IconType = React.ComponentType<{ size?: number; className?: string }>;

function getIconComponent(iconName: string): IconType {
  return (LucideIcons as unknown as Record<string, IconType>)[iconName] ?? Package;
}

export default function InventoryModal() {
  const { ui, setShowInventory, player, setInventory, useConsumableItem } = useGameStore();

  const [draggedSlot, setDraggedSlot] = useState<{ cat: ItemType; index: number } | null>(null);
  const [dropTarget, setDropTarget] = useState<{ cat: ItemType; index: number } | null>(null);
  const [splitState, setSplitState] = useState<{ cat: ItemType; index: number } | null>(null);
  const [splitAmount, setSplitAmount] = useState(1);
  const [tooltip, setTooltip] = useState<{ def: ItemDef; x: number; y: number } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortMode, setSortMode] = useState<SortMode>('rarity');
  const [sortMenuOpen, setSortMenuOpen] = useState(false);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [mounted, setMounted] = useState(false);
  const [closing, setClosing] = useState(false);

  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressFired = useRef(false);
  const touchStartPos = useRef<{ x: number; y: number } | null>(null);

  const open = ui.showInventory;

  useEffect(() => {
    if (open) {
      setMounted(true);
      setClosing(false);
    }
  }, [open]);

  const handleClose = useCallback(() => {
    setClosing(true);
    setTimeout(() => {
      setShowInventory(false);
      setSplitState(null);
      setTooltip(null);
      setSortMenuOpen(false);
    }, 200);
  }, [setShowInventory]);

  const activeCats = useMemo(() => getActiveCategories(player.inventory), [player.inventory]);
  const occupiedCount = useMemo(() => getOccupiedSlots(player.inventory), [player.inventory]);
  const healingCount = useMemo(
    () => HEALING_ITEM_IDS.reduce((sum, id) => sum + getItemCount(player.inventory, id), 0),
    [player.inventory]
  );

  const handleSlotClick = useCallback(
    (def: ItemDef) => {
      if (longPressFired.current) {
        longPressFired.current = false;
        return;
      }
      if (def.type === 'consumable') {
        useConsumableItem(def.name);
      }
    },
    [useConsumableItem]
  );

  const openSplitDialog = useCallback(
    (cat: ItemType, index: number) => {
      const slot = player.inventory.categories[cat]?.[index];
      if (!slot) return;
      const def = getItem(slot.itemId);
      if (!def || def.maxStack <= 1 || slot.count <= 1) return;
      setSplitState({ cat, index });
      setSplitAmount(1);
    },
    [player.inventory]
  );

  const handleSplitConfirm = useCallback(() => {
    if (!splitState) return;
    const result = splitStack(player.inventory, splitState.cat, splitState.index, splitAmount);
    if (result.success) setInventory(result.inv);
    setSplitState(null);
  }, [splitState, splitAmount, player.inventory, setInventory]);

  const handleSplitHalf = useCallback(() => {
    if (!splitState) return;
    const slot = player.inventory.categories[splitState.cat]?.[splitState.index];
    if (!slot) return;
    setSplitAmount(Math.floor(slot.count / 2));
  }, [splitState, player.inventory]);

  // --- Drag & drop (desktop HTML5 DnD) ---
  const handleDragStart = (cat: ItemType, index: number) => {
    setDraggedSlot({ cat, index });
  };
  const handleDragEnd = () => {
    setDraggedSlot(null);
    setDropTarget(null);
  };
  const handleDragOver = (e: React.DragEvent, cat: ItemType, index: number) => {
    e.preventDefault();
    setDropTarget({ cat, index });
  };
  const handleDrop = (targetCat: ItemType, targetIndex: number) => {
    if (!draggedSlot || draggedSlot.cat !== targetCat || draggedSlot.index === targetIndex) {
      setDraggedSlot(null);
      setDropTarget(null);
      return;
    }
    setInventory(moveItemWithinCategory(player.inventory, targetCat, draggedSlot.index, targetIndex));
    setDraggedSlot(null);
    setDropTarget(null);
  };

  // --- Long-press for mobile ---
  const handlePointerDown = (cat: ItemType, index: number, e: React.PointerEvent) => {
    longPressFired.current = false;
    touchStartPos.current = { x: e.clientX, y: e.clientY };
    longPressTimer.current = setTimeout(() => {
      longPressFired.current = true;
      openSplitDialog(cat, index);
    }, 500);
  };
  const handlePointerMove = (e: React.PointerEvent) => {
    if (!longPressTimer.current || !touchStartPos.current) return;
    const dx = Math.abs(e.clientX - touchStartPos.current.x);
    const dy = Math.abs(e.clientY - touchStartPos.current.y);
    if (dx > 8 || dy > 8) {
      if (longPressTimer.current) clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };
  const handlePointerUp = (def: ItemDef) => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
    if (!longPressFired.current) handleSlotClick(def);
  };
  const handlePointerEnter = (def: ItemDef, e: React.PointerEvent) => {
    if (longPressTimer.current) return;
    setTooltip({ def, x: e.clientX, y: e.clientY });
  };
  const handlePointerLeave = () => setTooltip(null);

  const handleContextMenu = (e: React.MouseEvent, cat: ItemType, index: number) => {
    e.preventDefault();
    openSplitDialog(cat, index);
  };

  const toggleCollapse = (cat: string) => {
    setCollapsed((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  const sortLabel = SORT_MODES.find((s) => s.key === sortMode)?.label ?? 'Rarity';

  if (!open && !mounted) return null;
  if (!open && closing) return null;

  return (
    <div
      className={`absolute inset-0 z-40 flex items-center justify-center bg-black/70 backdrop-blur-sm p-2 sm:p-4 transition-opacity duration-200 ${
        closing ? 'opacity-0' : 'opacity-100'
      }`}
      onPointerDown={(e) => {
        if (e.target === e.currentTarget) handleClose();
      }}
    >
      <div
        className={`bg-gray-900 border border-gray-700 rounded-xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] transition-all duration-200 ${
          closing ? 'scale-95 opacity-0' : 'scale-100 opacity-100'
        }`}
      >
        {/* Header */}
        <div className="p-3 sm:p-4 border-b border-gray-800 flex justify-between items-center bg-gray-950 shrink-0">
          <h2 className="text-lg sm:text-xl font-bold text-white tracking-wider">INVENTORY</h2>
          <div className="flex items-center gap-3">
            <span className="text-xs sm:text-sm text-amber-400 font-bold">{player.gold} Gold</span>
            <button onClick={handleClose} className="text-gray-400 hover:text-white transition-colors">
              <X size={24} />
            </button>
          </div>
        </div>

        {/* Toolbar: Search + Sort */}
        <div className="px-3 sm:px-4 py-2 border-b border-gray-800 flex items-center gap-2 bg-gray-950/50 shrink-0">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search items..."
              className="w-full pl-8 pr-3 py-1.5 bg-gray-800 border border-gray-700 text-white text-sm rounded-lg focus:outline-none focus:border-blue-500 placeholder:text-gray-500"
            />
          </div>
          <div className="relative">
            <button
              onClick={() => setSortMenuOpen(!sortMenuOpen)}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-gray-800 border border-gray-700 text-gray-300 text-sm rounded-lg hover:bg-gray-700 transition-colors"
            >
              <ArrowUpDown size={14} />
              <span className="hidden sm:inline">{sortLabel}</span>
              <ChevronDown size={12} />
            </button>
            {sortMenuOpen && (
              <div className="absolute right-0 top-full mt-1 bg-gray-800 border border-gray-700 rounded-lg shadow-xl py-1 z-10 min-w-[100px]">
                {SORT_MODES.map((mode) => (
                  <button
                    key={mode.key}
                    onClick={() => {
                      setSortMode(mode.key);
                      setSortMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 text-sm transition-colors ${
                      sortMode === mode.key ? 'text-blue-400 bg-blue-500/10' : 'text-gray-300 hover:bg-gray-700'
                    }`}
                  >
                    {mode.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Category Sections */}
        <div className="overflow-y-auto flex-1 min-h-[140px]">
          {activeCats.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full py-12 text-gray-500">
              <Package size={40} className="mb-2 opacity-40" />
              <p className="text-sm">Your inventory is empty.</p>
            </div>
          ) : (
            <div className="p-3 sm:p-4 space-y-3">
              {activeCats.map((cat) => {
                const meta = CATEGORY_META[cat];
                const CatIcon = getIconComponent(meta.icon);
                const isCollapsed = collapsed[cat] ?? false;
                const displaySlots = getCategoryDisplaySlots(player.inventory, cat, searchQuery, sortMode);
                if (searchQuery && displaySlots.length === 0) return null;

                return (
                  <div key={cat} className="border border-gray-800 rounded-lg overflow-hidden bg-gray-950/40">
                    <button
                      onClick={() => toggleCollapse(cat)}
                      className="w-full flex items-center justify-between px-3 py-2 bg-gray-800/60 hover:bg-gray-800 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <CatIcon size={16} className="text-blue-400" />
                        <span className="font-bold text-sm text-white tracking-wide">{meta.label}</span>
                        <span className="text-xs text-gray-500">({displaySlots.length})</span>
                      </div>
                      <ChevronDown
                        size={16}
                        className={`text-gray-500 transition-transform duration-200 ${isCollapsed ? '' : 'rotate-180'}`}
                      />
                    </button>

                    <div className={`overflow-hidden transition-all duration-200 ${isCollapsed ? 'max-h-0' : 'max-h-[1000px]'}`}>
                      <div className="p-2.5 sm:p-3">
                        <div
                          className="grid gap-2 sm:gap-2.5"
                          style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(56px, 1fr))' }}
                        >
                          {displaySlots.map(({ slot, index, def }) => {
                            const rarityColor = RARITY_COLORS[def.rarity];
                            const Icon = getIconComponent(def.icon);
                            const isDragged = draggedSlot?.cat === cat && draggedSlot.index === index;
                            const isDropTarget =
                              dropTarget?.cat === cat && dropTarget.index === index && draggedSlot !== null;

                            return (
                              <div
                                key={`${cat}-${index}-${slot.id}`}
                                draggable
                                onDragStart={() => handleDragStart(cat, index)}
                                onDragEnd={handleDragEnd}
                                onDragOver={(e) => handleDragOver(e, cat, index)}
                                onDrop={() => handleDrop(cat, index)}
                                onPointerDown={(e) => handlePointerDown(cat, index, e)}
                                onPointerMove={handlePointerMove}
                                onPointerUp={() => handlePointerUp(def)}
                                onPointerEnter={(e) => handlePointerEnter(def, e)}
                                onPointerLeave={handlePointerLeave}
                                onContextMenu={(e) => handleContextMenu(e, cat, index)}
                                className={`relative aspect-square rounded-lg border-2 flex flex-col items-center justify-center cursor-pointer transition-all duration-150 bg-gray-800 hover:bg-gray-700 hover:scale-105 ${
                                  RARITY_GLOW[def.rarity] ?? ''
                                } ${isDragged ? 'opacity-40 scale-90' : ''} ${
                                  isDropTarget ? 'border-blue-400 bg-blue-500/20 scale-105' : ''
                                }`}
                                style={{ borderColor: rarityColor }}
                              >
                                <Icon size={22} className="sm:w-7 sm:h-7" />
                                {slot.count > 1 && (
                                  <span className="absolute bottom-0.5 right-1 text-[10px] sm:text-xs font-bold text-white bg-black/70 rounded px-1 leading-tight">
                                    {slot.count}
                                  </span>
                                )}
                                {def.type === 'consumable' && (
                                  <span className="absolute top-0.5 left-1 text-[8px] text-emerald-400 font-bold leading-tight">
                                    USE
                                  </span>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-gray-800 bg-gray-950 shrink-0 flex items-center justify-between">
          <span className="text-xs text-gray-400">
            {occupiedCount} {occupiedCount === 1 ? 'slot' : 'slots'} occupied
          </span>
          <span className="text-xs text-emerald-400 font-semibold">
            {healingCount} healing {healingCount === 1 ? 'item' : 'items'}
          </span>
        </div>
      </div>

      {/* Tooltip */}
      {tooltip && (
        <div
          className="fixed z-50 pointer-events-none max-w-[240px]"
          style={{
            left: Math.min(tooltip.x + 16, (typeof window !== 'undefined' ? window.innerWidth : 9999) - 260),
            top: Math.min(tooltip.y + 16, (typeof window !== 'undefined' ? window.innerHeight : 9999) - 120),
          }}
        >
          <div
            className="bg-gray-950 border-2 rounded-lg p-3 shadow-2xl"
            style={{ borderColor: RARITY_COLORS[tooltip.def.rarity] }}
          >
            <div className="flex items-center gap-2 mb-1.5">
              {(() => {
                const Icon = getIconComponent(tooltip.def.icon);
                return <Icon size={18} />;
              })()}
              <span className="font-bold text-sm text-white">{tooltip.def.name}</span>
            </div>
            <div className="flex items-center gap-2 mb-2">
              <span
                className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded"
                style={{
                  color: RARITY_COLORS[tooltip.def.rarity],
                  backgroundColor: RARITY_COLORS[tooltip.def.rarity] + '20',
                }}
              >
                {tooltip.def.rarity}
              </span>
              <span className="text-[10px] text-gray-500 uppercase">{tooltip.def.type}</span>
              {tooltip.def.value > 0 && (
                <span className="text-[10px] text-amber-400 font-semibold">{tooltip.def.value}g</span>
              )}
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">{tooltip.def.description}</p>
          </div>
        </div>
      )}

      {/* Split Stack Modal */}
      {splitState && (
        <div
          className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          onPointerDown={(e) => {
            if (e.target === e.currentTarget) setSplitState(null);
          }}
        >
          <div className="bg-gray-900 border border-gray-700 rounded-xl p-5 sm:p-6 shadow-2xl w-full max-w-xs scale-100 opacity-100 transition-all duration-200">
            {(() => {
              const slot = player.inventory.categories[splitState.cat]?.[splitState.index];
              if (!slot) return null;
              const def = getItem(slot.itemId);
              if (!def) return null;
              const Icon = getIconComponent(def.icon);
              const max = slot.count - 1;
              return (
                <>
                  <div className="flex items-center gap-2 mb-4">
                    <Icon size={20} />
                    <h3 className="text-lg font-bold text-white">Split {def.name}</h3>
                  </div>
                  <div className="flex items-baseline justify-center gap-1 mb-4">
                    <span className="text-3xl font-bold text-white">{splitAmount}</span>
                    <span className="text-gray-500 text-lg">/ {slot.count}</span>
                  </div>
                  <input
                    type="range"
                    min={1}
                    max={max}
                    value={splitAmount}
                    onChange={(e) => setSplitAmount(Number(e.target.value))}
                    className="w-full mb-3 accent-blue-500"
                  />
                  <div className="flex justify-between mb-4">
                    <button
                      onClick={() => setSplitAmount(1)}
                      className="text-xs text-gray-400 hover:text-white transition-colors"
                    >
                      One
                    </button>
                    <button
                      onClick={handleSplitHalf}
                      className="text-xs text-gray-400 hover:text-white transition-colors"
                    >
                      Half
                    </button>
                    <button
                      onClick={() => setSplitAmount(max)}
                      className="text-xs text-gray-400 hover:text-white transition-colors"
                    >
                      All but one
                    </button>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setSplitState(null)}
                      className="flex-1 bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 rounded-lg transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSplitConfirm}
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded-lg transition-colors"
                    >
                      Split
                    </button>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}
