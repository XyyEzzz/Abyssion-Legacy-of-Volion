'use client';

import { useState } from 'react';
import { useGameStore } from '@/lib/store';
import { HudElementId, HUD_ELEMENT_LABELS } from '@/lib/hudConfig';
import { X, RotateCcw, Pencil, Eye, EyeOff, Bug, Activity, Users, MessageSquare, LogOut } from 'lucide-react';

type TabId = 'general' | 'graphics' | 'sensitivity' | 'debug';

const TABS: { id: TabId; label: string }[] = [
  { id: 'general', label: 'General' },
  { id: 'graphics', label: 'Graphics' },
  { id: 'sensitivity', label: 'Sensitivity' },
  { id: 'debug', label: 'Debug Mode' },
];

export default function SettingsModal() {
  const { settings, setSettings, ui, setShowSettings, saveGame, debug, activeDialogue, hudLayout, setHudElement, resetHudElement, resetHudLayout, setHudEditMode, returnToMenu } = useGameStore();
  const [activeTab, setActiveTab] = useState<TabId>('general');

  if (!ui.showSettings) return null;

  const hudElementIds = Object.keys(HUD_ELEMENT_LABELS) as HudElementId[];

  const toggleHudElement = (id: HudElementId) => {
    setHudElement(id, { visible: !hudLayout[id].visible });
  };

  const trueFalseBadge = (value: boolean) => (
    <span
      className={`px-1.5 py-0.5 text-[10px] font-bold ${
        value
          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
          : 'bg-slate-800 text-slate-400 border border-slate-700'
      }`}
    >
      {value ? 'TRUE' : 'FALSE'}
    </span>
  );

  const infoRow = (label: string, value: React.ReactNode) => (
    <div className="flex justify-between items-center gap-3">
      <span className="text-sm text-gray-300">{label}</span>
      <span className="font-mono text-sm text-gray-100">{value}</span>
    </div>
  );

  const tabButton = (tab: { id: TabId; label: string }) => (
    <button
      key={tab.id}
      onClick={() => setActiveTab(tab.id)}
      className={`flex-1 px-3 py-2 text-xs font-bold uppercase tracking-wider transition-colors border-b-2 ${
        activeTab === tab.id
          ? 'text-white border-red-500 bg-gray-800/50'
          : 'text-gray-500 border-transparent hover:text-gray-300 hover:bg-gray-800/30'
      }`}
    >
      {tab.label}
    </button>
  );

  const sectionTitle = (label: string) => (
    <h3 className="text-sm font-semibold text-red-400 uppercase tracking-widest">{label}</h3>
  );

  const selectClass = 'w-full bg-gray-800 border border-gray-700 text-white p-2 focus:outline-none focus:border-red-500';

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-gray-900 border border-gray-700 w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-800 flex justify-between items-center bg-gray-950">
          <h2 className="text-xl font-bold text-white tracking-wider">SYSTEM SETTINGS</h2>
          <button
            onClick={() => setShowSettings(false)}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Tab Bar */}
        <div className="flex border-b border-gray-800 bg-gray-950">
          {TABS.map(tabButton)}
        </div>

        {/* Tab Content */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[60vh]">

          {/* ── GENERAL ── */}
          {activeTab === 'general' && (
            <div className="space-y-6">
              {/* Camera Settings */}
              <div className="space-y-4">
                {sectionTitle('Camera')}

                <div className="space-y-2">
                  <label className="text-sm text-gray-300">Camera Mode</label>
                  <select
                    value={settings.cameraMode}
                    onChange={(e) => setSettings({ cameraMode: e.target.value as 'third' | 'second' | 'first' })}
                    className={selectClass}
                  >
                    <option value="third">Third Person</option>
                    <option value="second">Second Person</option>
                    <option value="first">First Person</option>
                  </select>
                </div>
              </div>

              {/* HUD Customization */}
              <div className="space-y-4 border-t border-gray-800 pt-5">
                <div className="flex items-center justify-between">
                  {sectionTitle('Customize HUD')}
                  <button
                    onClick={() => resetHudLayout()}
                    className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700 transition-colors"
                  >
                    <RotateCcw size={12} />
                    Reset All
                  </button>
                </div>

                <button
                  onClick={() => {
                    setShowSettings(false);
                    setHudEditMode(true);
                  }}
                  className="w-full flex items-center justify-center gap-2 px-3 py-2.5 text-sm font-bold bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 transition-colors"
                >
                  <Pencil size={15} />
                  Edit HUD Layout
                </button>

                <div className="bg-gray-950/50 border border-gray-800 p-4 space-y-2">
                  {hudElementIds.map((id) => (
                    <div key={id} className="flex items-center justify-between">
                      <span className="text-sm text-gray-300">{HUD_ELEMENT_LABELS[id]}</span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => resetHudElement(id)}
                          className="text-gray-500 hover:text-gray-300 transition-colors"
                          title="Reset this element"
                        >
                          <RotateCcw size={12} />
                        </button>
                        <button
                          onClick={() => toggleHudElement(id)}
                          className="text-gray-500 hover:text-gray-300 transition-colors"
                          title={hudLayout[id].visible ? 'Hide' : 'Show'}
                        >
                          {hudLayout[id].visible ? <Eye size={14} /> : <EyeOff size={14} />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── GRAPHICS ── */}
          {activeTab === 'graphics' && (
            <div className="space-y-4">
              {sectionTitle('Graphics')}

              <div className="space-y-2">
                <label className="text-sm text-gray-300">Resolution Scale</label>
                <select
                  value={settings.resolution}
                  onChange={(e) => setSettings({ resolution: e.target.value })}
                  className={selectClass}
                >
                  <option value="144p">144p</option>
                  <option value="240p">240p</option>
                  <option value="360p">360p</option>
                  <option value="480p">480p</option>
                  <option value="720p">720p</option>
                  <option value="1080p">1080p</option>
                  <option value="1440p">1440p</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-gray-300">FPS Target</label>
                <select
                  value={settings.fps}
                  onChange={(e) => setSettings({ fps: Number(e.target.value) })}
                  className={selectClass}
                >
                  <option value={15}>15 FPS (Battery Saver)</option>
                  <option value={30}>30 FPS</option>
                  <option value={45}>45 FPS</option>
                  <option value={60}>60 FPS</option>
                  <option value={75}>75 FPS</option>
                  <option value={90}>90 FPS</option>
                  <option value={120}>120 FPS</option>
                  <option value={144}>144 FPS</option>
                </select>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-300">Dynamic Shadows</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.shadows}
                    onChange={(e) => setSettings({ shadows: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
                </label>
              </div>
            </div>
          )}

          {/* ── SENSITIVITY ── */}
          {activeTab === 'sensitivity' && (
            <div className="space-y-4">
              {sectionTitle('Sensitivity')}

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-sm text-gray-300">Camera Sensitivity</label>
                  <span className="font-mono text-sm text-gray-100 tabular-nums">{settings.cameraSensitivity.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min={0.1}
                  max={3.0}
                  step={0.05}
                  value={settings.cameraSensitivity}
                  onChange={(e) => setSettings({ cameraSensitivity: Number(e.target.value) })}
                  className="w-full accent-red-500"
                />
                <div className="flex justify-between text-[10px] text-gray-500 font-mono">
                  <span>0.10x</span>
                  <span>1.00x (DEFAULT)</span>
                  <span>3.00x</span>
                </div>
                <p className="text-xs text-gray-500">Controls how fast the camera rotates in response to touch or mouse drag. Higher values rotate faster.</p>
              </div>
            </div>
          )}

          {/* ── DEBUG MODE ── */}
          {activeTab === 'debug' && (
            <div className="space-y-5">
              <div className="space-y-4">
                {sectionTitle('Debug Mode')}

                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">Enable Debug Telemetry</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.debugMode}
                      onChange={(e) => setSettings({ debugMode: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                  </label>
                </div>

                <p className="text-xs text-gray-500">
                  When enabled, a compact telemetry overlay appears at the top-center of the gameplay screen. It does not affect gameplay logic, movement, combat, or performance beyond the rendering cost of the overlay itself.
                </p>
              </div>

              {/* Debug Telemetry Preview (read-only, always visible in this tab) */}
              <div className="space-y-4 border-t border-gray-800 pt-5">
                <div className="flex items-center gap-2">
                  <Bug size={16} className="text-amber-400" />
                  <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-widest">Telemetry Preview</h3>
                </div>

                <div className="bg-gray-950/50 border border-gray-800 p-4 space-y-4">
                  {/* NPC Interaction */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5 mb-1">
                      <Users size={13} className="text-gray-400" />
                      <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">NPC Interaction</span>
                    </div>
                    {infoRow('Nearest NPC', debug.nearestNpcName || 'None')}
                    {infoRow(
                      'Distance',
                      debug.currentDistance < 900 ? `${debug.currentDistance.toFixed(2)}m` : 'N/A'
                    )}
                    <div className="flex justify-between items-center gap-3">
                      <span className="text-sm text-gray-300">Is Near (&le;3.8m)</span>
                      {trueFalseBadge(debug.isNear)}
                    </div>
                    {infoRow(
                      'E Pressed',
                      `${debug.ePressedCount}x${debug.ePressedCount > 0 ? ` @ ${debug.lastEPressedTime}` : ''}`
                    )}
                  </div>

                  {/* Dialogue System */}
                  <div className="space-y-2 border-t border-gray-800/50 pt-3">
                    <div className="flex items-center gap-1.5 mb-1">
                      <MessageSquare size={13} className="text-gray-400" />
                      <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Dialogue System</span>
                    </div>
                    {infoRow(
                      'Open Dialogue Calls',
                      `${debug.openDialogueCalledCount}x${
                        debug.openDialogueCalledCount > 0 ? ` @ ${debug.lastOpenDialogueTime}` : ''
                      }`
                    )}
                    <div className="flex justify-between items-center gap-3">
                      <span className="text-sm text-gray-300">Active Dialogue</span>
                      {trueFalseBadge(activeDialogue !== null)}
                    </div>
                    <div className="flex justify-between items-center gap-3">
                      <span className="text-sm text-gray-300">Dialogue Modal Mounted</span>
                      {trueFalseBadge(debug.dialogueModalMounted)}
                    </div>
                  </div>

                  {/* Live State */}
                  <div className="space-y-2 border-t border-gray-800/50 pt-3">
                    <div className="flex items-center gap-1.5 mb-1">
                      <Activity size={13} className="text-gray-400" />
                      <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Live State</span>
                    </div>
                    {infoRow('Dialogue Flag (store)', trueFalseBadge(debug.activeDialogueNotNull))}
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-800 bg-gray-950 flex gap-3">
          <button
            onClick={() => {
              saveGame();
              setShowSettings(false);
            }}
            className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 transition-colors"
          >
            Save & Apply
          </button>
          <button
            onClick={() => {
              returnToMenu();
            }}
            className="flex items-center gap-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 font-bold py-2 px-4 transition-colors border border-gray-700"
            title="Save and return to main menu"
          >
            <LogOut size={16} />
            <span className="hidden sm:inline text-xs uppercase tracking-wider">Main Menu</span>
          </button>
        </div>
      </div>
    </div>
  );
}
