'use client';

import { useGameStore } from '@/lib/store';
import { HUD_CONFIG as H } from '@/lib/hudConfig';
import { Settings, Backpack, Sword } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import DialogueModal from './DialogueModal';
import QuestLogModal from './QuestLogModal';
import InventoryModal from './InventoryModal';
import GameHUD from './GameHUD';
import HudEditor from './HudEditor';
import DebugTelemetry from './DebugTelemetry';
import DamageVignette from './DamageVignette';

export default function UI() {
  const { setShowSettings, setInputs, setShowInventory, hudEditMode } = useGameStore();
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth <= 1024 || 'ontouchstart' in window);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const joystickRef = useRef<HTMLDivElement>(null);
  const thumbRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const joystickPointerId = useRef<number | null>(null);
  const cameraPointerId = useRef<number | null>(null);
  const buttonPointers = useRef<Map<number, 'jump' | 'attack' | 'dodge' | 'sprint'>>(new Map());
  
  const joystickOrigin = useRef<{x: number, y: number} | null>(null);
  const lastCameraPos = useRef<{x: number, y: number} | null>(null);
  const currentCameraAngle = useRef<number>(0);
  const currentCameraPitch = useRef<number>(0);

  const updateJoystick = (clientX: number, clientY: number) => {
    if (!joystickOrigin.current || !joystickRef.current || !thumbRef.current) return;
    
    const rect = joystickRef.current.getBoundingClientRect();
    const maxRadius = rect.width / 2;
    
    let dx = clientX - joystickOrigin.current.x;
    let dy = clientY - joystickOrigin.current.y;
    
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance > maxRadius) {
      dx = (dx / distance) * maxRadius;
      dy = (dy / distance) * maxRadius;
    }
    
    thumbRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
    
    const nx = dx / maxRadius;
    const ny = dy / maxRadius;
    
    setInputs({ joystick: { x: nx, y: ny } });
  };

  const handlePointerDown = (e: PointerEvent) => {
    // Ignore gameplay pointer events while any modal overlay or editor is open —
    // prevents inventory/settings/HUD-editor touches from starting joystick or camera drags.
    const { showSettings, showInventory, showQuestLog } = useGameStore.getState().ui;
    const activeDialogue = useGameStore.getState().activeDialogue;
    if (showSettings || showInventory || showQuestLog || hudEditMode || activeDialogue) return;

    const target = e.target as HTMLElement;
    if (target.closest('button')) {
      return;
    }

    if (e.clientX < window.innerWidth / 2) {
      if (joystickPointerId.current === null) {
        joystickPointerId.current = e.pointerId;
        if (joystickRef.current) {
          const rect = joystickRef.current.getBoundingClientRect();
          joystickOrigin.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
        } else {
          joystickOrigin.current = { x: e.clientX, y: e.clientY };
        }
        updateJoystick(e.clientX, e.clientY);
      }
    } else {
      if (cameraPointerId.current === null) {
        cameraPointerId.current = e.pointerId;
        lastCameraPos.current = { x: e.clientX, y: e.clientY };
      }
    }
  };

  const handlePointerMove = (e: PointerEvent) => {
    // Cancel any active drag if a modal or editor opened mid-drag
    const { showSettings, showInventory, showQuestLog } = useGameStore.getState().ui;
    const activeDialogue = useGameStore.getState().activeDialogue;
    if (showSettings || showInventory || showQuestLog || hudEditMode || activeDialogue) {
      if (joystickPointerId.current !== null) {
        joystickPointerId.current = null;
        joystickOrigin.current = null;
        if (thumbRef.current) thumbRef.current.style.transform = `translate(0px, 0px)`;
        setInputs({ joystick: { x: 0, y: 0 } });
      }
      if (cameraPointerId.current !== null) {
        cameraPointerId.current = null;
        lastCameraPos.current = null;
      }
      // Also clear any stuck button inputs
      if (buttonPointers.current.size > 0) {
        const updates: Partial<Record<'jump' | 'attack' | 'dodge' | 'sprint', boolean>> = {};
        buttonPointers.current.forEach((action) => { updates[action] = false; });
        buttonPointers.current.clear();
        setInputs(updates);
      }
      return;
    }

    if (e.pointerId === joystickPointerId.current) {
      updateJoystick(e.clientX, e.clientY);
    } else if (e.pointerId === cameraPointerId.current && lastCameraPos.current) {
      const sens = useGameStore.getState().settings.cameraSensitivity;
      const dx = e.clientX - lastCameraPos.current.x;
      const dy = e.clientY - lastCameraPos.current.y;
      currentCameraAngle.current -= dx * 0.008 * sens;
      currentCameraPitch.current = Math.max(-Math.PI / 2 + 0.1, Math.min(Math.PI / 2 - 0.1, currentCameraPitch.current + dy * 0.008 * sens));
      setInputs({ cameraAngle: currentCameraAngle.current, cameraPitch: currentCameraPitch.current });
      lastCameraPos.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handlePointerUp = (e: PointerEvent) => {
    if (e.pointerId === joystickPointerId.current) {
      joystickPointerId.current = null;
      joystickOrigin.current = null;
      if (thumbRef.current) {
        thumbRef.current.style.transform = `translate(0px, 0px)`;
      }
      setInputs({ joystick: { x: 0, y: 0 } });
    } else if (e.pointerId === cameraPointerId.current) {
      cameraPointerId.current = null;
      lastCameraPos.current = null;
    } else if (buttonPointers.current.has(e.pointerId)) {
      const action = buttonPointers.current.get(e.pointerId);
      buttonPointers.current.delete(e.pointerId);
      if (action) {
        setInputs({ [action]: false });
      }
    }
  };

  const handleButtonPointerDown = (action: 'jump' | 'attack' | 'dodge' | 'sprint', e: React.PointerEvent) => {
    e.stopPropagation();
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {}
    buttonPointers.current.set(e.pointerId, action);
    setInputs({ [action]: true });
  };

  const handleButtonPointerUp = (action: 'jump' | 'attack' | 'dodge' | 'sprint', e: React.PointerEvent) => {
    e.stopPropagation();
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}
    if (buttonPointers.current.has(e.pointerId)) {
      buttonPointers.current.delete(e.pointerId);
    }
    setInputs({ [action]: false });
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const s = useGameStore.getState();
      const uiBlocked = s.ui.showSettings || s.ui.showInventory || s.ui.showQuestLog || s.hudEditMode || s.activeDialogue;
      if (uiBlocked) return;
      if (e.key === 'q' || e.key === 'Q' || e.key === 'h' || e.key === 'H') {
        s.useConsumableItem();
      }
      if (e.key === 'Tab' || e.key === 'i' || e.key === 'I') {
        e.preventDefault();
        setShowInventory(!s.ui.showInventory);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setShowInventory]);

  // Reset all gameplay inputs and active pointer tracking whenever any
  // modal or editor opens or closes. This prevents stuck movement, stuck
  // camera drags, and stuck button states (jump/attack/dodge/sprint) after
  // transitioning between gameplay and settings/inventory/HUD editor.
  const showSettings = useGameStore(s => s.ui.showSettings);
  const showInventory = useGameStore(s => s.ui.showInventory);
  const showQuestLog = useGameStore(s => s.ui.showQuestLog);
  const activeDialogue = useGameStore(s => s.activeDialogue);
  useEffect(() => {
    // Clear all active pointer tracking
    joystickPointerId.current = null;
    joystickOrigin.current = null;
    cameraPointerId.current = null;
    lastCameraPos.current = null;
    buttonPointers.current.clear();

    // Reset thumb visual
    if (thumbRef.current) {
      thumbRef.current.style.transform = 'translate(0px, 0px)';
    }

    // Reset all gameplay inputs to neutral state
    setInputs({
      joystick: { x: 0, y: 0 },
      jump: false,
      attack: false,
      dodge: false,
      sprint: false,
    });
  }, [hudEditMode, showSettings, showInventory, showQuestLog, activeDialogue, setInputs]);

  // Attach pointer listeners to the container and window. Re-attach when
  // hudEditMode changes because the container div is unmounted during edit
  // mode and remounted as a new element on close.
  useEffect(() => {
    if (hudEditMode) return;
    const container = containerRef.current;
    if (!container) return;

    const onDown = (e: PointerEvent) => handlePointerDown(e);
    const onMove = (e: PointerEvent) => handlePointerMove(e);
    const onUp = (e: PointerEvent) => handlePointerUp(e);

    container.addEventListener('pointerdown', onDown);
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);

    return () => {
      container.removeEventListener('pointerdown', onDown);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
    };
  }, [hudEditMode]);

  if (hudEditMode) {
    return <HudEditor />;
  }

  return (
    <div 
      ref={containerRef}
      className="absolute inset-0 z-10 select-none overflow-hidden touch-none"
      style={{ padding: 'env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)' }}
    >
      {/* Damage Vignette — red pulse when player takes damage */}
      <DamageVignette />

      {/* Custom Gameplay HUD */}
      <GameHUD />

      {/* Debug Telemetry — only renders when debug mode is enabled */}
      <DebugTelemetry />

      {/* Overlays / Modals */}
      <DialogueModal />
      <QuestLogModal />
      <InventoryModal />

      {/* Top Right — Inventory & Settings buttons */}
      <div className="absolute top-3 right-3 sm:top-5 sm:right-5 flex flex-col items-end gap-2 pointer-events-auto z-30">
        <div className="flex items-center gap-2">
          <button
            onTouchStart={(e) => { e.stopPropagation(); setShowInventory(true); }}
            onMouseDown={(e) => { e.stopPropagation(); setShowInventory(true); }}
            className="p-2 sm:p-2.5 rounded-lg backdrop-blur-sm shadow-lg transition-all active:scale-95"
            style={{
              background: H.colors.panelBg,
              border: `1px solid ${H.colors.panelBorder}`,
              color: H.colors.textPrimary,
            }}
            title="Inventory (Tab or I)"
          >
            <Backpack size={18} />
          </button>
          <button
            onTouchStart={(e) => { e.stopPropagation(); setShowSettings(true); }}
            onMouseDown={(e) => { e.stopPropagation(); setShowSettings(true); }}
            className="p-2 sm:p-2.5 rounded-lg backdrop-blur-sm shadow-lg transition-all active:scale-95"
            style={{
              background: H.colors.panelBg,
              border: `1px solid ${H.colors.panelBorder}`,
              color: H.colors.textPrimary,
            }}
          >
            <Settings size={18} />
          </button>
        </div>
      </div>

      {/* Mobile Controls */}
      {isMobile && (
        <>
          {/* Virtual Joystick Zone */}
          <div 
            className="absolute bottom-8 left-8 sm:bottom-12 sm:left-12 w-28 h-28 sm:w-36 sm:h-36 rounded-full border-2 backdrop-blur-sm pointer-events-none"
            style={{
              background: 'rgba(8,8,12,0.35)',
              borderColor: 'rgba(255,255,255,0.15)',
            }}
            ref={joystickRef}
          >
            <div 
              ref={thumbRef}
              className="absolute top-1/2 left-1/2 w-10 h-10 sm:w-14 sm:h-14 rounded-full -ml-5 -mt-5 sm:-ml-7 sm:-mt-7 shadow-lg pointer-events-none transition-transform duration-75 ease-out"
              style={{
                background: 'rgba(255,255,255,0.5)',
                border: '1px solid rgba(255,255,255,0.2)',
              }}
            />
          </div>

          {/* Action Buttons */}
          <div className="absolute bottom-8 right-8 sm:bottom-12 sm:right-12 flex items-end justify-end pointer-events-auto w-48 h-48 sm:w-56 sm:h-56">
             {/* Attack Button (Bottom Right) */}
             <button 
               onPointerDown={(e) => handleButtonPointerDown('attack', e)}
               onPointerUp={(e) => handleButtonPointerUp('attack', e)}
               onPointerCancel={(e) => handleButtonPointerUp('attack', e)}
               className="absolute bottom-0 right-0 w-20 h-20 sm:w-24 sm:h-24 rounded-full flex items-center justify-center text-white backdrop-blur-sm active:bg-white/20 touch-none select-none transition-all"
               style={{
                 background: 'rgba(8,8,12,0.8)',
                 border: '3px solid rgba(250,204,21,0.45)',
                 boxShadow: '0 0 14px rgba(250,204,21,0.25)',
               }}
             >
               <Sword size={32} className="sm:w-9 sm:h-9 pointer-events-none" style={{ color: '#facc15' }} />
             </button>
             
             {/* Jump Button (Top Right of Attack) */}
             <button 
               onPointerDown={(e) => handleButtonPointerDown('jump', e)}
               onPointerUp={(e) => handleButtonPointerUp('jump', e)}
               onPointerCancel={(e) => handleButtonPointerUp('jump', e)}
               className="absolute bottom-[90px] right-[10px] sm:bottom-[110px] sm:right-[10px] w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center text-white backdrop-blur-sm active:bg-white/20 touch-none shadow-lg select-none transition-all"
               style={{
                 background: 'rgba(8,8,12,0.65)',
                 border: '2px solid rgba(255,255,255,0.2)',
               }}
             >
               <span className="text-[10px] sm:text-xs font-bold pointer-events-none">JUMP</span>
             </button>

             {/* Dodge Button (Left of Attack) */}
             <button 
               onPointerDown={(e) => handleButtonPointerDown('dodge', e)}
               onPointerUp={(e) => handleButtonPointerUp('dodge', e)}
               onPointerCancel={(e) => handleButtonPointerUp('dodge', e)}
               className="absolute bottom-[10px] right-[90px] sm:bottom-[10px] sm:right-[110px] w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center text-white backdrop-blur-sm active:bg-white/20 touch-none shadow-lg select-none transition-all"
               style={{
                 background: 'rgba(8,8,12,0.65)',
                 border: '2px solid rgba(255,255,255,0.2)',
               }}
             >
               <span className="text-[10px] sm:text-xs font-bold pointer-events-none">DODGE</span>
             </button>

             {/* Sprint Button (Above Dodge) */}
             <button 
               onPointerDown={(e) => handleButtonPointerDown('sprint', e)}
               onPointerUp={(e) => handleButtonPointerUp('sprint', e)}
               onPointerCancel={(e) => handleButtonPointerUp('sprint', e)}
               className="absolute bottom-[90px] right-[90px] sm:bottom-[110px] sm:right-[110px] w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center text-white backdrop-blur-sm active:bg-white/20 touch-none shadow-lg select-none transition-all"
               style={{
                 background: 'rgba(8,8,12,0.65)',
                 border: '2px solid rgba(14,165,233,0.4)',
               }}
             >
               <span className="text-[10px] sm:text-xs font-bold pointer-events-none">SPRINT</span>
             </button>
          </div>
        </>
      )}
    </div>
  );
}
