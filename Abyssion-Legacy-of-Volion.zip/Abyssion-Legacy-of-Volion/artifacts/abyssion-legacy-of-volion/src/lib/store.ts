import { create } from 'zustand';
import * as THREE from 'three';
import { Quest, INITIAL_QUESTS, NPCS_DATA, NpcType } from './questData';
import { InventoryState, createInventory, addItem, removeItem, getItemCount, getItemCountByName, getOccupiedSlots, getActiveCategories } from './inventory';
import { getItem, getItemIdByName } from './items';
import { COMBAT_CONFIG } from './combatConfig';
import { HudLayout, HudElementId, HudElementConfig, DEFAULT_HUD_LAYOUT, migrateHudLayout } from './hudConfig';

export interface EnemyTarget {
  id: string;
  getPosition: () => THREE.Vector3;
  takeDamage: (damage: number, sourcePos: THREE.Vector3, comboStage: number) => boolean;
}

export const enemyTargets = new Map<string, EnemyTarget>();

export function registerEnemyTarget(target: EnemyTarget) {
  enemyTargets.set(target.id, target);
}

export function unregisterEnemyTarget(id: string) {
  enemyTargets.delete(id);
}

export interface LootItem {
  id: string;
  name: string;
  type: 'coin' | 'material' | 'equipment';
  x: number;
  y: number;
  z: number;
  amount: number;
  color: string;
}

export interface DamageNumber {
  id: string;
  x: number;
  y: number;
  z: number;
  text: string;
  color: string;
  createdAt: number;
}

export interface HitSpark {
  id: string;
  x: number;
  y: number;
  z: number;
  color: string;
  createdAt: number;
}

export interface SlashParticle {
  id: string;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  color: string;
  size: number;
  createdAt: number;
  lifetime: number;
}

export interface Notification {
  id: string;
  text: string;
  createdAt: number;
}

interface GameState {
  player: {
    health: number;
    maxHealth: number;
    stamina: number;
    maxStamina: number;
    position: [number, number, number];
    gold: number;
    exp: number;
    maxExp: number;
    level: number;
    inventory: InventoryState;
    invincible: boolean;
    isDodging: boolean;
    isAttacking: boolean;
    comboStage: number;
    comboConfirmed: boolean;
    attackCooldown: boolean;
    slowFactor?: number;
    lastDamageTime: number;
    lastStaminaTime: number;
    lastCombatTime: number;
    inCombat: boolean;
    checkpointPos: [number, number, number];
    itemCooldownUntil: number;
  };
  quests: Quest[];
  completedQuestIds: string[];
  encounterDefeats: string[];
  npcMemory: Record<string, 'met' | 'accepted' | 'completed'>;
  activeDialogue: {
    npcId: string;
    npcName: string;
    npcRole: string;
    npcType: NpcType;
    pages: string[];
    currentPage: number;
    questToOffer?: Quest;
    questToTurnIn?: Quest;
  } | null;
  boss: {
    name: string;
    health: number;
    maxHealth: number;
    active: boolean;
  } | null;
  damageNumbers: DamageNumber[];
  hitSparks: HitSpark[];
  slashParticles: SlashParticle[];
  cameraShakeRequest: { intensity: number; id: number } | null;
  hitStopMsRequest: { durationMs: number; id: number } | null;
  damageVignetteRequest: { intensity: number; id: number } | null;
  lootDrops: LootItem[];
  notifications: Notification[];
  settings: {
    resolution: string;
    fps: number;
    shadows: boolean;
    cameraMode: 'third' | 'second' | 'first';
    cameraSensitivity: number;
    debugMode: boolean;
  };
  hudLayout: HudLayout;
  hudEditMode: boolean;
  gamePhase: 'loading' | 'menu' | 'playing';
  saveSlots: SaveSlotSummary[];
  activeSlot: SaveSlotId;
  ui: {
    showSettings: boolean;
    showQuestLog: boolean;
    showInventory: boolean;
    interactPrompt: string | null;
    deathOverlay: boolean;
  };
  inputs: {
    jump: boolean;
    attack: boolean;
    dodge: boolean;
    sprint: boolean;
    joystick: { x: number; y: number };
    cameraAngle: number;
    cameraPitch: number;
  };
  debug: {
    nearestNpcName: string;
    currentDistance: number;
    isNear: boolean;
    ePressedCount: number;
    lastEPressedTime: string;
    openDialogueCalledCount: number;
    lastOpenDialogueTime: string;
    activeDialogueNotNull: boolean;
    dialogueModalMounted: boolean;
  };
  updateDebug: (data: Partial<GameState['debug']>) => void;
  setPlayerHealth: (health: number) => void;
  damagePlayer: (amount: number) => boolean; // returns true if hit was taken
  applyPlayerSlow: (durationMs: number, slowFactor?: number) => void;
  setPlayerStamina: (stamina: number) => void;
  setPlayerPosition: (pos: [number, number, number]) => void;
  setPlayerInvincible: (invincible: boolean) => void;
  triggerPlayerDodge: () => boolean; // returns true if dodge started
  triggerPlayerAttack: () => number; // returns combo stage (1,2,3) if attack started, 0 if blocked
  confirmComboHit: () => void; // advances combo display only on confirmed hit
  setSettings: (settings: Partial<GameState['settings']>) => void;
  setHudLayout: (layout: Partial<HudLayout>) => void;
  setHudElement: (id: HudElementId, config: Partial<HudElementConfig>) => void;
  resetHudElement: (id: HudElementId) => void;
  resetHudLayout: () => void;
  setHudEditMode: (enabled: boolean) => void;
  setGamePhase: (phase: 'loading' | 'menu' | 'playing') => void;
  refreshSaveSlots: () => void;
  startNewGame: (slotId?: SaveSlotId) => boolean;
  continueGame: (slotId?: SaveSlotId) => boolean;
  returnToMenu: () => void;
  setShowSettings: (show: boolean) => void;
  setShowQuestLog: (show: boolean) => void;
  setShowInventory: (show: boolean) => void;
  setInventory: (inv: InventoryState) => void;
  setInteractPrompt: (prompt: string | null) => void;
  setInputs: (inputs: Partial<GameState['inputs']>) => void;
  addDamageNumber: (x: number, y: number, z: number, text: string, color?: string) => void;
  removeDamageNumber: (id: string) => void;
  addHitSpark: (x: number, y: number, z: number, color?: string) => void;
  removeHitSpark: (id: string) => void;
  addSlashParticles: (x: number, y: number, z: number, dirX: number, dirZ: number, color?: string) => void;
  removeSlashParticle: (id: string) => void;
  triggerCameraShake: (intensity: number) => void;
  triggerHitStop: (durationMs?: number) => void;
  triggerDamageVignette: (intensity?: number) => void;
  addLootDrop: (loot: Omit<LootItem, 'id'>) => void;
  collectLootDrop: (id: string) => void;
  addNotification: (text: string) => void;
  addExp: (amount: number) => void;
  openDialogueForNpc: (npcId: string) => void;
  advanceDialogue: () => void;
  closeDialogue: () => void;
  acceptQuest: (questId: string) => void;
  completeQuest: (questId: string) => void;
  onEnemyKilled: (enemyName: string) => void;
  checkItemObjectives: () => void;
  checkLocationObjectives: (pos: [number, number, number]) => void;
  setBossState: (boss: GameState['boss']) => void;
  respawnPlayer: () => void;
  activateCheckpoint: (pos: [number, number, number]) => void;
  useConsumableItem: (requestedItemName?: string) => boolean;
  tickRegenerationAndCombat: (delta: number) => void;
  recordStaminaUse: () => void;
  saveGame: () => void;
  loadGame: (slotId?: SaveSlotId) => boolean;
}

export type SaveSlotId = 1 | 2 | 3;
export type SaveSlotStatus = 'empty' | 'occupied' | 'corrupted';

export interface SaveSlotSummary {
  id: SaveSlotId;
  status: SaveSlotStatus;
  savedAt: number | null;
  playerLevel: number | null;
}

interface PersistedSaveData {
  version: 1;
  savedAt: number;
  player: {
    health: number;
    maxHealth: number;
    stamina: number;
    maxStamina: number;
    position: [number, number, number];
    gold: number;
    exp: number;
    maxExp: number;
    level: number;
    inventory: InventoryState;
    checkpointPos: [number, number, number];
  };
  quests: Quest[];
  completedQuestIds: string[];
  encounterDefeats: string[];
  npcMemory: Record<string, 'met' | 'accepted' | 'completed'>;
}

const LEGACY_SAVE_KEY = 'abyssion_save';
const SAVE_SLOTS_KEY = 'abyssion_save_slots';
const ACTIVE_SLOT_KEY = 'abyssion_active_slot';
const GLOBAL_CONFIG_KEY = 'abyssion_global_config';
const SAVE_SLOT_IDS: SaveSlotId[] = [1, 2, 3];

type UnknownRecord = Record<string, unknown>;

function isRecord(value: unknown): value is UnknownRecord {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

function isVector3(value: unknown): value is [number, number, number] {
  return Array.isArray(value)
    && value.length === 3
    && value.every((component) => typeof component === 'number' && Number.isFinite(component));
}

function isSaveSlotId(value: unknown): value is SaveSlotId {
  return value === 1 || value === 2 || value === 3;
}

function getStorage(): Storage | null {
  if (typeof window === 'undefined') return null;
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

function parseStorageValue(raw: string | null): unknown {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as unknown;
  } catch {
    return undefined;
  }
}

function readSlotRecords(): { records: unknown[]; validContainer: boolean } {
  const storage = getStorage();
  if (!storage) return { records: [null, null, null], validContainer: true };

  const raw = storage.getItem(SAVE_SLOTS_KEY);
  if (raw === null) return { records: [null, null, null], validContainer: true };

  const parsed = parseStorageValue(raw);
  if (Array.isArray(parsed) && parsed.length === SAVE_SLOT_IDS.length) {
    return { records: parsed, validContainer: true };
  }

  if (isRecord(parsed) && Array.isArray(parsed.slots) && parsed.slots.length === SAVE_SLOT_IDS.length) {
    return { records: parsed.slots, validContainer: true };
  }

  return { records: [undefined, undefined, undefined], validContainer: false };
}

function isPersistedSaveData(value: unknown): value is PersistedSaveData {
  if (!isRecord(value) || !isRecord(value.player)) return false;
  const player = value.player;
  return isVector3(player.position);
}

function getPersistedSaveData(value: unknown): PersistedSaveData | null {
  if (!isRecord(value)) return null;
  const candidate = isRecord(value.progress) ? value.progress : value;
  return isPersistedSaveData(candidate) ? candidate : null;
}

function getSaveSlotSummaries(
  records: unknown[],
  validContainer = true,
): SaveSlotSummary[] {
  return SAVE_SLOT_IDS.map((id, index) => {
    const record = records[index];
    if (!validContainer || record === undefined) {
      return { id, status: 'corrupted', savedAt: null, playerLevel: null };
    }
    if (record === null) {
      return { id, status: 'empty', savedAt: null, playerLevel: null };
    }

    const parsed = getPersistedSaveData(record);
    if (!parsed) {
      return { id, status: 'corrupted', savedAt: null, playerLevel: null };
    }

    return {
      id,
      status: 'occupied',
      savedAt: typeof parsed.savedAt === 'number' && Number.isFinite(parsed.savedAt)
        ? parsed.savedAt
        : null,
      playerLevel: typeof parsed.player.level === 'number' && Number.isFinite(parsed.player.level)
        ? parsed.player.level
        : null,
    };
  });
}

function readActiveSlot(): SaveSlotId {
  const raw = getStorage()?.getItem(ACTIVE_SLOT_KEY);
  const parsed = raw ? Number(raw) : NaN;
  return isSaveSlotId(parsed) ? parsed : 1;
}

function persistActiveSlot(slotId: SaveSlotId) {
  getStorage()?.setItem(ACTIVE_SLOT_KEY, String(slotId));
}

function readGlobalConfig(): { settings?: UnknownRecord; hudLayout?: unknown } {
  const parsed = parseStorageValue(getStorage()?.getItem(GLOBAL_CONFIG_KEY) ?? null);
  if (!isRecord(parsed)) return {};
  return {
    settings: isRecord(parsed.settings) ? parsed.settings : undefined,
    hudLayout: parsed.hudLayout,
  };
}

function writeGlobalConfig(settings: GameState['settings'], hudLayout: HudLayout) {
  const storage = getStorage();
  if (!storage) return;
  try {
    storage.setItem(GLOBAL_CONFIG_KEY, JSON.stringify({ settings, hudLayout }));
  } catch (error) {
    console.error('Failed to save global game configuration', error);
  }
}

function writeSlotRecords(records: unknown[]): boolean {
  const storage = getStorage();
  if (!storage || records.length !== SAVE_SLOT_IDS.length) return false;

  try {
    storage.setItem(SAVE_SLOTS_KEY, JSON.stringify(records));
    const verification = readSlotRecords();
    return verification.validContainer && verification.records.length === SAVE_SLOT_IDS.length;
  } catch (error) {
    console.error('Failed to save game slots', error);
    return false;
  }
}

function migrateLegacySaveIfNeeded(): { records: unknown[]; validContainer: boolean } {
  const slots = readSlotRecords();
  const legacyRaw = getStorage()?.getItem(LEGACY_SAVE_KEY) ?? null;
  const legacyValue = parseStorageValue(legacyRaw);
  const legacySave = getPersistedSaveData(legacyValue);

  if (!legacySave || !slots.validContainer) return slots;

  const emptyIndex = slots.records.findIndex((record) => record === null);
  if (emptyIndex < 0) return slots;

  let legacyRecord: UnknownRecord | PersistedSaveData = legacySave;
  if (isRecord(legacyValue)) {
    const { settings: _settings, hudLayout: _hudLayout, ...legacyProgress } = legacyValue;
    legacyRecord = {
      ...legacyProgress,
      version: 1,
      savedAt: typeof legacyValue.savedAt === 'number' && Number.isFinite(legacyValue.savedAt)
        ? legacyValue.savedAt
        : Date.now(),
    };
  }

  const nextRecords = [...slots.records];
  nextRecords[emptyIndex] = legacyRecord;
  if (!writeSlotRecords(nextRecords)) return slots;

  const verification = readSlotRecords();
  if (!getPersistedSaveData(verification.records[emptyIndex])) return slots;

  const legacyConfig = isRecord(legacyValue)
    ? { settings: legacyValue.settings, hudLayout: legacyValue.hudLayout }
    : {};
  const existingConfig = readGlobalConfig();
  const legacySettings = isRecord(legacyConfig.settings) ? legacyConfig.settings : null;
  const legacyHudLayout = legacyConfig.hudLayout;
  if (
    (!existingConfig.settings && legacySettings)
    || (existingConfig.hudLayout === undefined && legacyHudLayout !== undefined)
  ) {
    const defaultSettings: GameState['settings'] = {
      resolution: '1080p',
      fps: 60,
      shadows: true,
      cameraMode: 'third',
      cameraSensitivity: 1.0,
      debugMode: false,
    };
    writeGlobalConfig(
      (existingConfig.settings ?? legacySettings ?? defaultSettings) as GameState['settings'],
      existingConfig.hudLayout === undefined
        ? migrateHudLayout(legacyHudLayout)
        : migrateHudLayout(existingConfig.hudLayout),
    );
  }

  // Retire the old representation only after the new slot was written and verified.
  getStorage()?.removeItem(LEGACY_SAVE_KEY);
  return verification;
}

function inspectPersistence() {
  const slots = migrateLegacySaveIfNeeded();
  const globalConfig = readGlobalConfig();
  return {
    ...slots,
    summaries: getSaveSlotSummaries(slots.records, slots.validContainer),
    activeSlot: readActiveSlot(),
    globalConfig,
  };
}

const initialPersistence = inspectPersistence();

function createStarterInventory(): InventoryState {
  let inv = createInventory();
  inv = addItem(inv, 'wooden_sword', 1).inv;
  inv = addItem(inv, 'health_potion', 3).inv;
  inv = addItem(inv, 'apple', 2).inv;
  return inv;
}

// Tracks the active i-frame timeout so a dodge can cancel a stale damage
// i-frame timer — otherwise the damage timeout fires mid-dodge and clears
// invincibility while the dodge i-frame should still be active.
let iframeTimeoutId: ReturnType<typeof setTimeout> | null = null;

export const useGameStore = create<GameState>((set, get) => ({
  player: {
    health: 100,
    maxHealth: 100,
    stamina: 100,
    maxStamina: 100,
    position: [0, 1, 0],
    gold: 50,
    exp: 0,
    maxExp: 100,
    level: 1,
    inventory: createStarterInventory(),
    invincible: false,
    isDodging: false,
    isAttacking: false,
    comboStage: 0,
    comboConfirmed: false,
    attackCooldown: false,
    slowFactor: 1.0,
    lastDamageTime: 0,
    lastStaminaTime: 0,
    lastCombatTime: 0,
    inCombat: false,
    checkpointPos: [0, 1, 0],
    itemCooldownUntil: 0,
  },
  quests: INITIAL_QUESTS,
  completedQuestIds: [],
  encounterDefeats: [],
  npcMemory: {},
  activeDialogue: null,
  boss: null,
  damageNumbers: [],
  hitSparks: [],
  slashParticles: [],
  cameraShakeRequest: null,
  hitStopMsRequest: null,
  damageVignetteRequest: null,
  lootDrops: [],
  notifications: [],
  settings: {
    resolution: '1080p',
    fps: 60,
    shadows: true,
    cameraMode: 'third',
    cameraSensitivity: 1.0,
    debugMode: false,
    ...initialPersistence.globalConfig.settings,
  },
  hudLayout: initialPersistence.globalConfig.hudLayout === undefined
    ? { ...DEFAULT_HUD_LAYOUT }
    : migrateHudLayout(initialPersistence.globalConfig.hudLayout),
  hudEditMode: false,
  gamePhase: 'loading',
  saveSlots: initialPersistence.summaries,
  activeSlot: initialPersistence.activeSlot,
  ui: {
    showSettings: false,
    showQuestLog: false,
    showInventory: false,
    interactPrompt: null,
    deathOverlay: false,
  },
  inputs: {
    jump: false,
    attack: false,
    dodge: false,
    sprint: false,
    joystick: { x: 0, y: 0 },
    cameraAngle: 0,
    cameraPitch: 0,
  },
  debug: {
    nearestNpcName: 'None',
    currentDistance: 999,
    isNear: false,
    ePressedCount: 0,
    lastEPressedTime: 'Never',
    openDialogueCalledCount: 0,
    lastOpenDialogueTime: 'Never',
    activeDialogueNotNull: false,
    dialogueModalMounted: false,
  },

  updateDebug: (data) =>
    set((state) => ({
      debug: { ...state.debug, ...data },
    })),

  setPlayerHealth: (health) => set((state) => ({ player: { ...state.player, health: Math.max(0, Math.min(state.player.maxHealth, health)) } })),
  
  damagePlayer: (amount) => {
    const { player, ui } = get();
    if (player.invincible || player.isDodging || ui.deathOverlay || player.health <= 0) return false;

    const newHealth = Math.max(0, player.health - amount);
    const now = Date.now();
    set((state) => ({
      player: {
        ...state.player,
        health: newHealth,
        invincible: true,
        lastDamageTime: now,
        lastCombatTime: now,
        inCombat: true,
      }
    }));

    // Grant i-frames matching dodge i-frame window
    if (iframeTimeoutId) clearTimeout(iframeTimeoutId);
    iframeTimeoutId = setTimeout(() => {
      iframeTimeoutId = null;
      set((state) => ({ player: { ...state.player, invincible: false } }));
    }, COMBAT_CONFIG.dodgeIframeMs);

    // Spawn damage number over player
    const pos = player.position;
    get().addDamageNumber(pos[0], pos[1] + 1.8, pos[2], `-${amount}`, '#ef4444');
    get().triggerCameraShake(COMBAT_CONFIG.damageCameraImpulse);
    get().triggerDamageVignette(COMBAT_CONFIG.damageVignetteIntensity);

    // Handle Death
    if (newHealth <= 0) {
      set((state) => ({ ui: { ...state.ui, deathOverlay: true } }));
      setTimeout(() => {
        get().respawnPlayer();
      }, 2000);
    }

    return true;
  },

  recordStaminaUse: () => {
    set((state) => ({
      player: { ...state.player, lastStaminaTime: Date.now() }
    }));
  },

  applyPlayerSlow: (durationMs: number, slowFactor = 0.5) => {
    set((state) => ({ player: { ...state.player, slowFactor } }));
    setTimeout(() => {
      set((state) => ({ player: { ...state.player, slowFactor: 1.0 } }));
    }, durationMs);
  },

  setPlayerStamina: (stamina) => set((state) => ({ player: { ...state.player, stamina: Math.max(0, Math.min(state.player.maxStamina, stamina)) } })),
  
  setPlayerPosition: (position) => {
    const prev = get().player.position;
    if (prev[0] === position[0] && prev[1] === position[1] && prev[2] === position[2]) return;
    set((state) => ({ player: { ...state.player, position } }));
  },
  
  setPlayerInvincible: (invincible) => set((state) => ({ player: { ...state.player, invincible } })),

  triggerPlayerDodge: () => {
    const { player } = get();
    if (player.isDodging || player.stamina < COMBAT_CONFIG.dodgeStaminaCost) return false;

    const now = Date.now();
    set((state) => ({
      player: {
        ...state.player,
        stamina: state.player.stamina - COMBAT_CONFIG.dodgeStaminaCost,
        isDodging: true,
        invincible: true,
        lastStaminaTime: now,
      }
    }));

    // End dodge roll state after dodge duration
    setTimeout(() => {
      set((state) => ({ player: { ...state.player, isDodging: false } }));
    }, COMBAT_CONFIG.dodgeDurationMs);

    // I-frames extend slightly beyond the dodge roll. Cancel any stale damage
    // i-frame timeout so it can't clear invincibility during the dodge window.
    if (iframeTimeoutId) clearTimeout(iframeTimeoutId);
    iframeTimeoutId = setTimeout(() => {
      iframeTimeoutId = null;
      set((state) => ({ player: { ...state.player, invincible: false } }));
    }, COMBAT_CONFIG.dodgeIframeMs);

    return true;
  },

  triggerPlayerAttack: () => {
    const { player } = get();
    if (player.attackCooldown) return 0;

    // A later combo stage is earned only by a confirmed hit. If the previous
    // swing missed, the next attack starts a fresh stage-1 swing instead of
    // incorrectly advancing through the combo.
    let nextCombo = player.comboConfirmed ? (player.comboStage % 3) + 1 : 1;
    set((state) => ({
      player: {
        ...state.player,
        isAttacking: true,
        comboStage: nextCombo,
        comboConfirmed: false,
        attackCooldown: true,
      }
    }));

    // Reset attacking state and set cooldown
    setTimeout(() => {
      set((state) => ({ player: { ...state.player, isAttacking: false } }));
    }, COMBAT_CONFIG.attackActiveMs);

    setTimeout(() => {
      set((state) => ({ player: { ...state.player, attackCooldown: false } }));
    }, COMBAT_CONFIG.attackCooldownMs);

    // Reset combo if no attack within combo reset window. If the hit was
    // never confirmed (missed), reset comboStage to 0 so the counter hides.
    setTimeout(() => {
      const current = get().player;
      if (!current.isAttacking && current.comboStage === nextCombo) {
        set((state) => ({ player: { ...state.player, comboStage: 0, comboConfirmed: false } }));
      }
    }, COMBAT_CONFIG.comboResetMs);

    return nextCombo;
  },

  confirmComboHit: () => {
    const { player } = get();
    if (player.comboStage > 0 && !player.comboConfirmed) {
      const now = Date.now();
      set((state) => ({ player: { ...state.player, comboConfirmed: true, lastCombatTime: now, inCombat: true } }));
    }
  },

  tickRegenerationAndCombat: (delta: number) => {
    const { player } = get();
    const now = Date.now();
    let updatedHealth = player.health;
    let updatedStamina = player.stamina;
    let inCombat = player.inCombat;

    // 1. Passive Health Regen: Starts after 5s without taking damage -> +5 HP/s
    if (now - player.lastDamageTime >= 5000 && updatedHealth < player.maxHealth && updatedHealth > 0) {
      updatedHealth = Math.min(player.maxHealth, updatedHealth + 5 * delta);
    }

    // 2. Passive Stamina Regen: Starts after 0.75s without consuming stamina -> +25 Stamina/s
    if (now - player.lastStaminaTime >= 750 && updatedStamina < player.maxStamina) {
      updatedStamina = Math.min(player.maxStamina, updatedStamina + 25 * delta);
    }

    // 3. Combat Recovery: Combat ends if no attacks or damage taken for 5 seconds
    if (inCombat && now - player.lastCombatTime >= 5000) {
      inCombat = false;
      const hpGain = Math.round(player.maxHealth * 0.05); // +5% Max HP
      const stamGain = Math.round(player.maxStamina * 0.3); // +30% Max Stamina
      updatedHealth = Math.min(player.maxHealth, updatedHealth + hpGain);
      updatedStamina = Math.min(player.maxStamina, updatedStamina + stamGain);
      get().addNotification('Combat Ended! Recovered +5% HP & +30% Stamina');
    }

    // Skip the store update entirely when nothing changed — avoids creating
    // a new player object 60×/sec and triggering unnecessary React re-renders.
    if (
      updatedHealth === player.health &&
      updatedStamina === player.stamina &&
      inCombat === player.inCombat
    ) {
      return;
    }

    set((state) => ({
      player: {
        ...state.player,
        health: updatedHealth,
        stamina: updatedStamina,
        inCombat,
      }
    }));
  },

  useConsumableItem: (requestedItemName) => {
    const { player } = get();
    const now = Date.now();

    if (now < player.itemCooldownUntil) {
      const remainingSec = Math.ceil((player.itemCooldownUntil - now) / 1000);
      get().addNotification(`Healing Item on Cooldown (${remainingSec}s)`);
      return false;
    }

    const priorityIds = ['health_potion', 'small_potion', 'bread', 'apple'];
    let targetId: string | undefined;

    if (requestedItemName) {
      targetId = getItemIdByName(requestedItemName);
    } else {
      for (const id of priorityIds) {
        if (getItemCount(player.inventory, id) > 0) {
          targetId = id;
          break;
        }
      }
    }

    if (!targetId) {
      get().addNotification('No Healing Items in Inventory!');
      return false;
    }

    if (getItemCount(player.inventory, targetId) <= 0) {
      const def = getItem(targetId);
      get().addNotification(`No ${def?.name ?? 'item'} left!`);
      return false;
    }

    if (player.health >= player.maxHealth) {
      get().addNotification('Health is already full!');
      return false;
    }

    const def = getItem(targetId);
    const healAmount = (def?.metadata?.healAmount as number) ?? 25;
    const newHealth = Math.min(player.maxHealth, player.health + healAmount);

    const { inv: updatedInv } = removeItem(player.inventory, targetId, 1);

    set((state) => ({
      player: {
        ...state.player,
        health: newHealth,
        inventory: updatedInv,
        itemCooldownUntil: now + 10000,
      }
    }));

    get().addNotification(`Used ${def?.name ?? 'Item'} (+${healAmount} HP)`);
    const pos = player.position;
    get().addDamageNumber(pos[0], pos[1] + 2.0, pos[2], `+${healAmount} HP`, '#22c55e');

    return true;
  },

  activateCheckpoint: (checkpointPos) => {
    set((state) => ({
      player: {
        ...state.player,
        health: state.player.maxHealth,
        stamina: state.player.maxStamina,
        checkpointPos,
      }
    }));
    get().addNotification('Checkpoint Activated! HP & Stamina Restored');
    get().saveGame();
  },

  setSettings: (newSettings) => set((state) => ({ settings: { ...state.settings, ...newSettings } })),
  setHudLayout: (partial) => set((state) => ({ hudLayout: { ...state.hudLayout, ...partial } })),
  setHudElement: (id, config) => set((state) => ({
    hudLayout: { ...state.hudLayout, [id]: { ...state.hudLayout[id], ...config } },
  })),
  resetHudElement: (id) => set((state) => ({
    hudLayout: { ...state.hudLayout, [id]: { ...DEFAULT_HUD_LAYOUT[id] } },
  })),
  resetHudLayout: () => set({ hudLayout: { ...DEFAULT_HUD_LAYOUT } }),
  setHudEditMode: (enabled) => set({ hudEditMode: enabled }),
  setGamePhase: (phase) => set({ gamePhase: phase }),
  refreshSaveSlots: () => {
    const persistence = inspectPersistence();
    const globalConfig = persistence.globalConfig;
    set((state) => ({
      saveSlots: persistence.summaries,
      activeSlot: persistence.activeSlot,
      settings: {
        ...state.settings,
        ...(globalConfig.settings ?? {}),
      },
      hudLayout: globalConfig.hudLayout === undefined
        ? state.hudLayout
        : migrateHudLayout(globalConfig.hudLayout),
    }));
  },
  startNewGame: (requestedSlotId) => {
    const { settings, hudLayout, saveSlots, activeSlot } = get();
    const slotId = requestedSlotId ?? activeSlot;
    const selectedSlot = saveSlots.find((slot) => slot.id === slotId);
    if (!selectedSlot || selectedSlot.status !== 'empty') return false;

    persistActiveSlot(slotId);
    set({
      activeSlot: slotId,
      player: {
        health: 100,
        maxHealth: 100,
        stamina: 100,
        maxStamina: 100,
        position: [0, 1, 0],
        gold: 50,
        exp: 0,
        maxExp: 100,
        level: 1,
        inventory: createStarterInventory(),
        invincible: false,
        isDodging: false,
        isAttacking: false,
        comboStage: 0,
        comboConfirmed: false,
        attackCooldown: false,
        slowFactor: 1.0,
        lastDamageTime: 0,
        lastStaminaTime: 0,
        lastCombatTime: 0,
        inCombat: false,
        checkpointPos: [0, 1, 0],
        itemCooldownUntil: 0,
      },
      quests: INITIAL_QUESTS,
      completedQuestIds: [],
      encounterDefeats: [],
      npcMemory: {},
      activeDialogue: null,
      boss: null,
      damageNumbers: [],
      hitSparks: [],
      slashParticles: [],
      lootDrops: [],
      notifications: [],
      cameraShakeRequest: null,
      hitStopMsRequest: null,
      damageVignetteRequest: null,
      settings,
      hudLayout,
      hudEditMode: false,
      gamePhase: 'playing',
      ui: {
        showSettings: false,
        showQuestLog: false,
        showInventory: false,
        interactPrompt: null,
        deathOverlay: false,
      },
      inputs: {
        jump: false,
        attack: false,
        dodge: false,
        sprint: false,
        joystick: { x: 0, y: 0 },
        cameraAngle: 0,
        cameraPitch: 0,
      },
    });
    get().saveGame();
    return true;
  },
  continueGame: (requestedSlotId) => {
    const loaded = get().loadGame(requestedSlotId);
    if (!loaded) return false;
    set({
      gamePhase: 'playing',
      hudEditMode: false,
      activeDialogue: null,
      boss: null,
      damageNumbers: [],
      hitSparks: [],
      slashParticles: [],
      lootDrops: [],
      notifications: [],
      cameraShakeRequest: null,
      hitStopMsRequest: null,
      damageVignetteRequest: null,
      ui: {
        showSettings: false,
        showQuestLog: false,
        showInventory: false,
        interactPrompt: null,
        deathOverlay: false,
      },
      inputs: {
        jump: false,
        attack: false,
        dodge: false,
        sprint: false,
        joystick: { x: 0, y: 0 },
        cameraAngle: 0,
        cameraPitch: 0,
      },
    });
    return true;
  },
  returnToMenu: () => {
    get().saveGame();
    set({
      gamePhase: 'menu',
      hudEditMode: false,
      activeDialogue: null,
      boss: null,
      damageNumbers: [],
      hitSparks: [],
      slashParticles: [],
      lootDrops: [],
      notifications: [],
      cameraShakeRequest: null,
      hitStopMsRequest: null,
      damageVignetteRequest: null,
      inputs: {
        jump: false,
        attack: false,
        dodge: false,
        sprint: false,
        joystick: { x: 0, y: 0 },
        cameraAngle: 0,
        cameraPitch: 0,
      },
      ui: {
        showSettings: false,
        showQuestLog: false,
        showInventory: false,
        interactPrompt: null,
        deathOverlay: false,
      },
    });
  },
  setShowSettings: (show) => set((state) => ({ ui: { ...state.ui, showSettings: show } })),
  setInteractPrompt: (prompt) => set((state) => ({ ui: { ...state.ui, interactPrompt: prompt } })),
  setInputs: (inputs) => set((state) => ({ inputs: { ...state.inputs, ...inputs } })),

  addDamageNumber: (x, y, z, text, color = '#facc15') => {
    const id = Math.random().toString(36).substring(2, 9);
    set((state) => ({
      damageNumbers: [...state.damageNumbers, { id, x, y, z, text, color, createdAt: Date.now() }]
    }));
    setTimeout(() => {
      get().removeDamageNumber(id);
    }, 800);
  },

  removeDamageNumber: (id) => {
    set((state) => ({
      damageNumbers: state.damageNumbers.filter(d => d.id !== id)
    }));
  },

  addHitSpark: (x, y, z, color = COMBAT_CONFIG.hitSparkColorNormal) => {
    const id = Math.random().toString(36).substring(2, 9);
    set((state) => ({
      hitSparks: [...state.hitSparks, { id, x, y, z, color, createdAt: Date.now() }]
    }));
    setTimeout(() => {
      get().removeHitSpark(id);
    }, COMBAT_CONFIG.hitSparkDurationMs);
  },

  removeHitSpark: (id) => {
    set((state) => ({
      hitSparks: state.hitSparks.filter(h => h.id !== id)
    }));
  },

  addSlashParticles: (x, y, z, dirX, dirZ, color = COMBAT_CONFIG.slashParticleColor) => {
    const newParticles: SlashParticle[] = [];
    for (let i = 0; i < COMBAT_CONFIG.slashParticleCount; i++) {
      const id = Math.random().toString(36).substring(2, 9) + '_' + i;
      const spread = (Math.random() - 0.5) * 1.5;
      const speed = COMBAT_CONFIG.slashParticleSpeed * (0.7 + Math.random() * 0.6);
      newParticles.push({
        id,
        x, y, z,
        vx: dirX * speed + spread,
        vy: 1.0 + Math.random() * 1.5,
        vz: dirZ * speed + spread,
        color,
        size: COMBAT_CONFIG.slashParticleSize,
        createdAt: Date.now(),
        lifetime: COMBAT_CONFIG.slashParticleLifetime,
      });
    }
    set((state) => ({
      slashParticles: [...state.slashParticles, ...newParticles]
    }));
    setTimeout(() => {
      set((state) => ({
        slashParticles: state.slashParticles.filter(p => !newParticles.some(np => np.id === p.id))
      }));
    }, COMBAT_CONFIG.slashParticleLifetime * 1000);
  },

  removeSlashParticle: (id) => {
    set((state) => ({
      slashParticles: state.slashParticles.filter(p => p.id !== id)
    }));
  },

  triggerCameraShake: (intensity) => {
    set({ cameraShakeRequest: { intensity, id: Date.now() + Math.random() } });
  },

  triggerHitStop: (durationMs = COMBAT_CONFIG.hitStopMs) => {
    set({ hitStopMsRequest: { durationMs, id: Date.now() + Math.random() } });
  },

  triggerDamageVignette: (intensity = COMBAT_CONFIG.damageVignetteIntensity) => {
    set({ damageVignetteRequest: { intensity, id: Date.now() + Math.random() } });
  },

  addLootDrop: (loot) => {
    const id = Math.random().toString(36).substring(2, 9);
    set((state) => ({
      lootDrops: [...state.lootDrops, { ...loot, id }]
    }));
  },

  collectLootDrop: (id) => {
    const { lootDrops, player } = get();
    const item = lootDrops.find(l => l.id === id);
    if (!item) return;

    if (item.type === 'coin') {
      set((state) => ({
        player: { ...state.player, gold: state.player.gold + item.amount },
        lootDrops: state.lootDrops.filter(l => l.id !== id)
      }));
      get().addNotification(`+${item.amount} Gold Coins`);
    } else {
      const itemId = getItemIdByName(item.name);
      if (itemId) {
        const { inv: updatedInv, added } = addItem(player.inventory, itemId, item.amount);
        set((state) => ({
          player: { ...state.player, inventory: updatedInv },
          lootDrops: state.lootDrops.filter(l => l.id !== id)
        }));
        get().addNotification(`Picked up ${item.name} (x${added})`);
      } else {
        set((state) => ({
          lootDrops: state.lootDrops.filter(l => l.id !== id)
        }));
      }
    }
    get().checkItemObjectives();
  },

  setShowQuestLog: (show) => set((state) => ({ ui: { ...state.ui, showQuestLog: show } })),
  setShowInventory: (show) => set((state) => ({ ui: { ...state.ui, showInventory: show } })),
  setInventory: (inv) => set((state) => ({ player: { ...state.player, inventory: inv } })),

  addExp: (amount) => {
    const { player } = get();
    let exp = player.exp + amount;
    let maxExp = player.maxExp;
    let level = player.level;
    let health = player.health;
    let maxHealth = player.maxHealth;
    let stamina = player.stamina;
    let maxStamina = player.maxStamina;

    let leveledUp = false;
    while (exp >= maxExp) {
      exp -= maxExp;
      level += 1;
      maxExp = Math.round(maxExp * 1.5);
      maxHealth += 20;
      health = maxHealth;
      maxStamina += 10;
      stamina = maxStamina;
      leveledUp = true;
    }

    set((state) => ({
      player: {
        ...state.player,
        exp,
        maxExp,
        level,
        health,
        maxHealth,
        stamina,
        maxStamina,
      }
    }));

    if (leveledUp) {
      get().addNotification(`🎉 LEVEL UP! Reached Level ${level}! Stats Boosted!`);
      const pos = player.position;
      get().addDamageNumber(pos[0], pos[1] + 2.5, pos[2], `LEVEL UP ${level}!`, '#f59e0b');
    }
  },

  openDialogueForNpc: (npcId) => {
    console.log(`[store.openDialogueForNpc] called with npcId:`, npcId);
    const npc = NPCS_DATA.find((n) => n.id === npcId);
    if (!npc) {
      console.log(`[store.openDialogueForNpc] NPC NOT FOUND for npcId:`, npcId);
      return;
    }

    const { quests, completedQuestIds } = get();
    let pages: string[] = [];
    let questToOffer: Quest | undefined = undefined;
    let questToTurnIn: Quest | undefined = undefined;

    if (npc.questId) {
      const quest = quests.find((q) => q.id === npc.questId);
      if (quest) {
        if (quest.status === 'unaccepted') {
          const prereqMet = !quest.prerequisiteQuestId || completedQuestIds.includes(quest.prerequisiteQuestId);
          if (prereqMet) {
            pages = npc.dialogue.questOffer.dialogue;
            questToOffer = quest;
          } else {
            pages = [
              ...npc.dialogue.greeting,
              'I have an important request, but you should finish your current tasks first.',
            ];
          }
        } else if (quest.status === 'active') {
          const allDone = quest.objectives.every((o) => o.currentAmount >= o.requiredAmount);
          if (allDone) {
            pages = npc.dialogue.questTurnIn;
            questToTurnIn = quest;
          } else {
            pages = npc.dialogue.questInProgress;
          }
        } else if (quest.status === 'ready_to_turn_in') {
          pages = npc.dialogue.questTurnIn;
          questToTurnIn = quest;
        } else if (quest.status === 'completed') {
          pages = npc.dialogue.questCompleted;
        }
      }
    }

    if (pages.length === 0) {
      pages = [...npc.dialogue.greeting, ...npc.dialogue.randomPool];
    }

    const newDialogue = {
      npcId: npc.id,
      npcName: npc.name,
      npcRole: npc.role,
      npcType: npc.type,
      pages,
      currentPage: 0,
      questToOffer,
      questToTurnIn,
    };

    console.log(`[store.openDialogueForNpc] setting activeDialogue state to:`, newDialogue);

    const nowStr = new Date().toLocaleTimeString();
    set((state) => ({
      activeDialogue: newDialogue,
      npcMemory: { ...state.npcMemory, [npcId]: 'met' },
      debug: {
        ...state.debug,
        openDialogueCalledCount: state.debug.openDialogueCalledCount + 1,
        lastOpenDialogueTime: nowStr,
        activeDialogueNotNull: true,
      },
    }));
  },

  advanceDialogue: () => {
    const { activeDialogue } = get();
    if (!activeDialogue) return;
    if (activeDialogue.currentPage < activeDialogue.pages.length - 1) {
      set((state) => ({
        activeDialogue: state.activeDialogue
          ? { ...state.activeDialogue, currentPage: state.activeDialogue.currentPage + 1 }
          : null,
      }));
    }
  },

  closeDialogue: () => {
    set((state) => ({
      activeDialogue: null,
      debug: {
        ...state.debug,
        activeDialogueNotNull: false,
      },
    }));
  },

  acceptQuest: (questId) => {
    const { quests } = get();
    const quest = quests.find((q) => q.id === questId);
    if (!quest) return;

    const updatedQuests = quests.map((q) => (q.id === questId ? { ...q, status: 'active' as const } : q));

    set((state) => ({
      quests: updatedQuests,
      npcMemory: { ...state.npcMemory, [quest.giverNpcId]: 'accepted' },
      activeDialogue: state.activeDialogue
        ? {
            ...state.activeDialogue,
            pages: ['Quest Accepted! Good luck out there!'],
            currentPage: 0,
            questToOffer: undefined,
          }
        : null,
    }));

    get().addNotification(`📜 Quest Accepted: ${quest.title}`);
    get().checkItemObjectives();
  },

  completeQuest: (questId) => {
    const { quests, player, completedQuestIds } = get();
    const quest = quests.find((q) => q.id === questId);
    if (!quest || quest.status === 'completed') return;

    const updatedQuests = quests.map((q) => (q.id === questId ? { ...q, status: 'completed' as const } : q));

    let updatedGold = player.gold + quest.rewards.coins;
    let updatedInv = player.inventory;

    if (quest.rewards.items) {
      for (const rewardItem of quest.rewards.items) {
        const itemId = getItemIdByName(rewardItem.name);
        if (itemId) {
          const result = addItem(updatedInv, itemId, rewardItem.count);
          updatedInv = result.inv;
        }
      }
    }

    set((state) => ({
      quests: updatedQuests,
      completedQuestIds: [...state.completedQuestIds, questId],
      npcMemory: { ...state.npcMemory, [quest.giverNpcId]: 'completed' },
      player: {
        ...state.player,
        gold: updatedGold,
        inventory: updatedInv,
      },
      activeDialogue: null,
    }));

    get().addExp(quest.rewards.exp);
    get().addNotification(`🏆 Quest Complete: ${quest.title}! Received Rewards!`);
    get().saveGame();
  },

  onEnemyKilled: (enemyName) => {
    const { quests } = get();
    let changed = false;

    const updatedQuests = quests.map((quest) => {
      if (quest.status !== 'active') return quest;

      let questUpdated = false;
      const updatedObjectives = quest.objectives.map((obj) => {
        if (obj.type === 'defeat' && (obj.target.toLowerCase() === enemyName.toLowerCase() || enemyName.toLowerCase().includes(obj.target.toLowerCase()))) {
          if (obj.currentAmount < obj.requiredAmount) {
            questUpdated = true;
            changed = true;
            const nextAmt = obj.currentAmount + 1;
            get().addNotification(`🎯 ${quest.title}: ${obj.description} (${nextAmt}/${obj.requiredAmount})`);
            return { ...obj, currentAmount: nextAmt };
          }
        }
        return obj;
      });

      if (questUpdated) {
        const allCompleted = updatedObjectives.every((o) => o.currentAmount >= o.requiredAmount);
        const nextStatus = allCompleted ? ('ready_to_turn_in' as const) : ('active' as const);
        if (allCompleted) {
          get().addNotification(`✨ Quest Ready to Turn In: ${quest.title}! Return to Giver.`);
        }
        return { ...quest, objectives: updatedObjectives, status: nextStatus };
      }

      return quest;
    });

    if (changed) {
      set({ quests: updatedQuests });
    }

    // Track encounter defeats for arena completion
    set((state) => ({
      encounterDefeats: state.encounterDefeats.includes(enemyName)
        ? state.encounterDefeats
        : [...state.encounterDefeats, enemyName],
    }));
  },

  checkItemObjectives: () => {
    const { quests, player } = get();
    let changed = false;

    const updatedQuests = quests.map((quest) => {
      if (quest.status !== 'active') return quest;

      let questUpdated = false;
      const updatedObjectives = quest.objectives.map((obj) => {
        if (obj.type === 'collect') {
          const count = getItemCountByName(player.inventory, obj.target);
          if (count !== obj.currentAmount) {
            questUpdated = true;
            changed = true;
            return { ...obj, currentAmount: Math.min(obj.requiredAmount, count) };
          }
        }
        return obj;
      });

      if (questUpdated) {
        const allCompleted = updatedObjectives.every((o) => o.currentAmount >= o.requiredAmount);
        const nextStatus = allCompleted ? ('ready_to_turn_in' as const) : ('active' as const);
        if (allCompleted) {
          get().addNotification(`✨ Quest Ready to Turn In: ${quest.title}! Return to Giver.`);
        }
        return { ...quest, objectives: updatedObjectives, status: nextStatus };
      }

      return quest;
    });

    if (changed) {
      set({ quests: updatedQuests });
    }
  },

  checkLocationObjectives: (playerPos) => {
    const { quests } = get();
    let changed = false;

    const updatedQuests = quests.map((quest) => {
      if (quest.status !== 'active') return quest;

      let questUpdated = false;
      const updatedObjectives = quest.objectives.map((obj) => {
        if (obj.type === 'reach' && obj.location && obj.currentAmount < obj.requiredAmount) {
          const dx = playerPos[0] - obj.location[0];
          const dz = playerPos[2] - obj.location[2];
          const distSq = dx * dx + dz * dz;
          if (distSq <= 25) { // 5m radius
            questUpdated = true;
            changed = true;
            get().addNotification(`📍 Discovered Location: ${obj.target}!`);
            return { ...obj, currentAmount: 1 };
          }
        }
        return obj;
      });

      if (questUpdated) {
        const allCompleted = updatedObjectives.every((o) => o.currentAmount >= o.requiredAmount);
        const nextStatus = allCompleted ? ('ready_to_turn_in' as const) : ('active' as const);
        if (allCompleted) {
          get().addNotification(`✨ Quest Ready to Turn In: ${quest.title}! Return to Giver.`);
        }
        return { ...quest, objectives: updatedObjectives, status: nextStatus };
      }

      return quest;
    });

    if (changed) {
      set({ quests: updatedQuests });
    }
  },

  addNotification: (text) => {
    const id = Math.random().toString(36).substring(2, 9);
    set((state) => ({
      notifications: [...state.notifications.slice(-3), { id, text, createdAt: Date.now() }]
    }));
    setTimeout(() => {
      set((state) => ({
        notifications: state.notifications.filter(n => n.id !== id)
      }));
    }, 2500);
  },

  setBossState: (boss) => set({ boss }),

  respawnPlayer: () => {
    set((state) => ({
      player: {
        ...state.player,
        health: state.player.maxHealth,
        stamina: state.player.maxStamina,
        position: state.player.checkpointPos || [0, 1, 0],
        invincible: false,
        isDodging: false,
        isAttacking: false,
        inCombat: false,
      },
      ui: {
        ...state.ui,
        deathOverlay: false,
      }
    }));
    get().addNotification('Respawned at Checkpoint');
  },

  saveGame: () => {
    const state = get();
    const slots = readSlotRecords();
    if (!slots.validContainer) {
      console.error('Cannot save game: save-slot data is corrupted');
      return;
    }

    const {
      health,
      maxHealth,
      stamina,
      maxStamina,
      position,
      gold,
      exp,
      maxExp,
      level,
      inventory,
      checkpointPos,
    } = state.player;
    const saveData: PersistedSaveData = {
      version: 1,
      savedAt: Date.now(),
      // Persist progression and recoverable gameplay state only. Combat
      // timers/i-frames are runtime state and must not resume half-finished.
      player: {
        health,
        maxHealth,
        stamina,
        maxStamina,
        maxExp,
        position,
        gold,
        exp,
        level,
        inventory,
        checkpointPos,
      },
      quests: state.quests,
      completedQuestIds: state.completedQuestIds,
      encounterDefeats: state.encounterDefeats,
      npcMemory: state.npcMemory,
    };

    const nextRecords = [...slots.records];
    nextRecords[state.activeSlot - 1] = saveData;
    if (!writeSlotRecords(nextRecords)) return;

    persistActiveSlot(state.activeSlot);
    writeGlobalConfig(state.settings, state.hudLayout);
    const updatedSlots = readSlotRecords();
    set({
      saveSlots: getSaveSlotSummaries(updatedSlots.records, updatedSlots.validContainer),
    });
    console.log('Game Saved', { slot: state.activeSlot, saveData });
  },

  loadGame: (requestedSlotId) => {
    const slotId = requestedSlotId ?? get().activeSlot;
    const slots = readSlotRecords();
    const parsed = slots.validContainer
      ? getPersistedSaveData(slots.records[slotId - 1])
      : null;

    if (!parsed) {
      set({
        saveSlots: getSaveSlotSummaries(slots.records, slots.validContainer),
      });
      return false;
    }

    const loadedPlayer = parsed.player as unknown as UnknownRecord;
    let loadedInventory: InventoryState;
    if (isRecord(loadedPlayer.inventory) && isRecord(loadedPlayer.inventory.categories)) {
      // Native category-native save format
      loadedInventory = { categories: loadedPlayer.inventory.categories as InventoryState['categories'] };
    } else if (isRecord(loadedPlayer.inventory) && Array.isArray(loadedPlayer.inventory.slots)) {
      // Legacy flat-slot save: migrate into category-native structure
      let migrated = createInventory();
      for (const slot of loadedPlayer.inventory.slots) {
        if (isRecord(slot) && typeof slot.itemId === 'string' && typeof slot.count === 'number') {
          migrated = addItem(migrated, slot.itemId, slot.count).inv;
        }
      }
      loadedInventory = migrated;
    } else if (Array.isArray(loadedPlayer.inventory)) {
      // Oldest legacy save: flat array of { name, type, count }
      let legacyInv = createInventory();
      for (const item of loadedPlayer.inventory) {
        if (isRecord(item) && typeof item.name === 'string' && typeof item.count === 'number') {
          const itemId = getItemIdByName(item.name);
          if (itemId) legacyInv = addItem(legacyInv, itemId, item.count).inv;
        }
      }
      loadedInventory = legacyInv;
    } else {
      loadedInventory = createStarterInventory();
    }

    const globalConfig = readGlobalConfig();
    const legacySettings: UnknownRecord = isRecord(parsed) && isRecord(parsed.settings)
      ? parsed.settings
      : {};
    const legacyHudLayout = isRecord(parsed) ? (parsed as UnknownRecord).hudLayout : undefined;
    const settingsFromStorage: UnknownRecord = globalConfig.settings ?? legacySettings;

    set((state) => ({
      activeSlot: slotId,
      saveSlots: getSaveSlotSummaries(slots.records, slots.validContainer),
      player: {
        ...state.player,
        ...loadedPlayer,
        inventory: loadedInventory,
        invincible: false,
        isDodging: false,
        isAttacking: false,
        comboStage: 0,
        comboConfirmed: false,
        attackCooldown: false,
        slowFactor: 1,
        lastDamageTime: 0,
        lastStaminaTime: 0,
        lastCombatTime: 0,
        inCombat: false,
        itemCooldownUntil: 0,
      },
      settings: {
        ...state.settings,
        ...settingsFromStorage,
      },
      hudLayout: globalConfig.hudLayout !== undefined
        ? migrateHudLayout(globalConfig.hudLayout)
        : legacyHudLayout !== undefined
          ? migrateHudLayout(legacyHudLayout)
          : state.hudLayout,
      quests: Array.isArray(parsed.quests) ? parsed.quests : INITIAL_QUESTS,
      completedQuestIds: Array.isArray(parsed.completedQuestIds) ? parsed.completedQuestIds : [],
      encounterDefeats: Array.isArray(parsed.encounterDefeats) ? parsed.encounterDefeats : [],
      npcMemory: isRecord(parsed.npcMemory)
        ? parsed.npcMemory as GameState['npcMemory']
        : {},
    }));
    persistActiveSlot(slotId);
    console.log('Game Loaded', { slot: slotId, saveData: parsed });
    return true;
  }
}));

