export type ItemType = 'weapon' | 'consumable' | 'material' | 'equipment' | 'key';
export type ItemRarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';

export interface ItemDef {
  id: string;
  name: string;
  description: string;
  rarity: ItemRarity;
  icon: string;
  type: ItemType;
  maxStack: number;
  value: number;
  metadata?: Record<string, unknown>;
}

export const RARITY_COLORS: Record<ItemRarity, string> = {
  common: '#9ca3af',
  uncommon: '#22c55e',
  rare: '#3b82f6',
  epic: '#a855f7',
  legendary: '#f59e0b',
};

const ITEMS: Record<string, ItemDef> = {
  wooden_sword: {
    id: 'wooden_sword',
    name: 'Wooden Sword',
    description: 'A basic training sword. Better than nothing.',
    rarity: 'common',
    icon: 'Sword',
    type: 'weapon',
    maxStack: 1,
    value: 10,
  },
  iron_sword: {
    id: 'iron_sword',
    name: 'Iron Sword',
    description: 'A sturdy iron blade forged by a master blacksmith.',
    rarity: 'uncommon',
    icon: 'Sword',
    type: 'weapon',
    maxStack: 1,
    value: 80,
  },
  health_potion: {
    id: 'health_potion',
    name: 'Health Potion',
    description: 'Restores 40 HP. A staple for any adventurer.',
    rarity: 'uncommon',
    icon: 'FlaskConical',
    type: 'consumable',
    maxStack: 99,
    value: 30,
    metadata: { healAmount: 40 },
  },
  small_potion: {
    id: 'small_potion',
    name: 'Small Potion',
    description: 'Restores 25 HP. A cheaper alternative for minor wounds.',
    rarity: 'common',
    icon: 'FlaskRound',
    type: 'consumable',
    maxStack: 99,
    value: 15,
    metadata: { healAmount: 25 },
  },
  bread: {
    id: 'bread',
    name: 'Bread',
    description: 'Restores 20 HP. Simple but filling.',
    rarity: 'common',
    icon: 'Wheat',
    type: 'consumable',
    maxStack: 99,
    value: 5,
    metadata: { healAmount: 20 },
  },
  apple: {
    id: 'apple',
    name: 'Apple',
    description: 'Restores 15 HP. A quick snack from the orchard.',
    rarity: 'common',
    icon: 'Apple',
    type: 'consumable',
    maxStack: 99,
    value: 3,
    metadata: { healAmount: 15 },
  },
  iron_ore: {
    id: 'iron_ore',
    name: 'Iron Ore',
    description: 'Raw iron recovered from bandit gear. Used for forging.',
    rarity: 'uncommon',
    icon: 'Gem',
    type: 'material',
    maxStack: 99,
    value: 20,
  },
  arcane_shard: {
    id: 'arcane_shard',
    name: 'Arcane Shard',
    description: 'A fragment of crystallized magic energy.',
    rarity: 'rare',
    icon: 'Sparkles',
    type: 'material',
    maxStack: 99,
    value: 50,
  },
};

const NAME_TO_ID: Record<string, string> = Object.values(ITEMS).reduce(
  (acc, item) => {
    acc[item.name.toLowerCase()] = item.id;
    return acc;
  },
  {} as Record<string, string>
);

export function getItem(id: string): ItemDef | undefined {
  return ITEMS[id];
}

export function getItemByName(name: string): ItemDef | undefined {
  const id = NAME_TO_ID[name.toLowerCase()];
  return id ? ITEMS[id] : undefined;
}

export function getItemIdByName(name: string): string | undefined {
  return NAME_TO_ID[name.toLowerCase()];
}

export function getAllItems(): ItemDef[] {
  return Object.values(ITEMS);
}
